<?php include('includes/header.php'); ?>
<style type="text/css">
.heading_about {
    font-size: 15px;
    font-weight: bold;
    color: #2e4193;
    margin-top: 30px;
}
</style>

<div class="body-custom-well">
<div class="container ">

<h1 class="heading-bloger text-center">Privacy Policy</h1>

<h4 class="heading_about">* Personal identification information</h4>
<p>We may collect personal identification information from Users in a variety of ways, including, but not limited to, when Users visit our site, fill out a form, and in connection with other activities, services, features or resources we make available on our Site. Users may be asked for, as appropriate, name, email address. Users may, however, visit our Site anonymously. We will collect personal identification information from Users only if they voluntarily submit such information to us. Users can always refuse to supply personally identification information, except that it may prevent them from engaging in certain Site related activities.</p>

<h4 class="heading_about">* Non-personal identification information</h4>
<p>We may collect non-personal identification information about Users whenever they interact with our Site. Non-personal identification information may include the browser name, the type of computer and technical information about Users means of connection to our Site, such as the operating system and the Internet service providers utilized and other similar information.</p>

<h4 class="heading_about">* How we protect your information</h4>
<p>We adopt appropriate data collection, storage and processing practices and security measures to protect against unauthorized access, alteration, disclosure or destruction of your personal information, username, password, transaction information and data stored on our Site.</p>

<h4 class="heading_about">* Sharing your personal information</h4>
<p>We do not sell, trade, or rent Users personal identification information to others. We may share generic aggregated demographic information not linked to any personal identification information regarding visitors and users with our business partners, trusted affiliates and advertisers for the purposes outlined above.We may use third party service providers to help us operate our business and the Site or administer activities on our behalf, such as sending out newsletters or surveys. We may share your information with these third parties for those limited purposes provided that you have given us your permission.</p>


<h4 class="heading_about">* Advertising</h4>
<p>Ads appearing on our site may be delivered to Users by advertising partners, who may set cookies. These cookies allow the ad server to recognize your computer each time they send you an online advertisement to compile non personal identification information about you or others who use your computer. This information allows ad networks to, among other things, deliver targeted advertisements that they believe will be of most interest to you. This privacy policy does not cover the use of cookies by any advertisers.</p>

<h4 class="heading_about">* Google Adsense</h4>
<p>Some of the ads may be served by Google. Google's use of the DART cookie enables it to serve ads to Users based on their visit to our Site and other sites on the Internet. DART uses "non personally identifiable information" and does NOT track personal information about you, such as your name, email address, physical address, etc. You may opt out of the use of the DART cookie by visiting the Google ad and content network privacy policy at http://www.google.com/privacy_ads.html</p>


<h4 class="heading_about">* Your acceptance of these terms</h4>
<p>By using this Site, you signify your acceptance of this policy. If you do not agree to this policy, please do not use our Site. Your continued use of the Site following the posting of changes to this policy will be deemed your acceptance of those changes.</p>


<h4 class="heading_about">* Changes to this privacy policy</h4>
<p>Facebook Video Downloader has the discretion to update this privacy policy at any time. When we do, we will revise the updated date at the bottom of this page and send you an email. We encourage Users to frequently check this page for any changes to stay informed about how we are helping to protect the personal information we collect. You acknowledge and agree that it is your responsibility to review this privacy policy periodically and become aware of modifications.</p>

<h4 class="heading_about">* Contacting us</h4>
<p>If you have any questions about this Privacy Policy, the practices of this site, or your dealings with this site, please contact us at:
<a href="contact_us.php" target="blank">https://freefbdown.com/contact_us.php</a>

</div>
</div>
<?php include('includes/footer.php'); ?>
