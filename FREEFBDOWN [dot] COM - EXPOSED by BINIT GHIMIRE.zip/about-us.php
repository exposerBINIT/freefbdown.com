<?php include('includes/header.php'); ?>

<style type="text/css">
.heading_about {
    font-size: 15px;
    font-weight: bold;
    color: #2e4193;
    margin-top: 30px;
}
</style>

<div class="body-custom-well">
<div class="container ">

<center><h1 class="heading-bloger">About Us</h1></center>
<p></p><p></p>
<p>This Website is a Free to use that helps Facebook users download their favorite videos off Facebook and save them for offline viewing by generating direct links to the Facebook video. It enables many features like Fast Direct Download, Easy Interface for Navigation and Download, Powerful Video Fetching Processor...</p>
<p>This website also works on all mobile phones and smartphones like iPhone, Android, Windows Phone.
We run Google Ads on our website, in order to feed our servers and keep <strong>FREEFBDOWN</strong> alive. If you want to support us, just disable your AdBlocker while using <strong>FREEFBDOWN.COM</strong> and we promise we only use safe & non intrusive ads.</p>

</div>
</div>
<?php include('includes/footer.php'); ?>
