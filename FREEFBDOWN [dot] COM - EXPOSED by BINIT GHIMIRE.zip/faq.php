<?php include('includes/header.php'); ?>
<style type="text/css">
  .heading_about {
    font-size: 15px;
    font-weight: bold;
    color: #2e4193;
    margin-top: 30px;
}
</style>
<!--disply result-- -->
<div class="body-custom-well">
<div class="container ">
      <h1 class="heading-bloger text-center">Frequently Asked Questions</h1>
      <div class="panel-group" id="faqAccordion" style="margin: 20px;" >
          <div class="panel panel-default ">
              <div class="panel-heading">
                  <h4 class="panel-title">
                    <a href="#" class="ing heading_about">Q: Where are videos saved after being downloaded?</a>
                  </h4>
              </div>
              <div class="panel-body">
                       <h5><span class="label label-primary">Answer</span></h5>
                       <p>It depends on the OS and Browser you are using, but usually all videos are saved under "Downloads" folder on Windows and Mac. You can also press CTRL+J in your Browser to view your download history.</p>
                       <!-- <a href="http://jquery2dotnet.com/" class="label label-success">http://jquery2dotnet.com/</a> -->                  
              </div>
          </div>
          <div class="panel panel-default ">
              <div class="panel-heading">
                    <h4 class="panel-title">
                      <a href="#" class="ing heading_about">Q: Why the video is playing instead of downloading?</a>
                    </h4>

              </div>
              <div class="panel-body">
                       <h5><span class="label label-primary">Answer</span></h5>
                      <p>That's something normal to happen, especially on browsers other than Chrome. To solve this issue, instead of left clicking the Download Video link, <strong>Right Click -> Save as...</strong> and choose the location you'd like to save the video to.</p>
              </div>
          </div>
          <div class="panel panel-default ">
              <div class="panel-heading">
                    <h4 class="panel-title">
                      <a href="#" class="ing heading_about">Q: Can I download Live Facebook videos?</a>
                    </h4>
              </div>
              <div class="panel-body">
                       <h5><span class="label label-primary">Answer</span></h5>
                       <p>Yes, you can download Facebook Live videos but only after they finish streaming.</p>
              </div>
          </div>
          <div class="panel panel-default ">
              <div class="panel-heading">
                    <h4 class="panel-title">
                      <a href="#" class="ing heading_about">Q: Does FREEFBDOWN store downloaded videos or keep a copy of videos?</a>
                    </h4>
              </div>
              <div class="panel-body">
                       <h5><span class="label label-primary">Answer</span></h5>
                      
                      <p>FREEFBDOWN doesn't store videos neither we keep copies of downloaded videos. <strong>All videos are hosted on Facebook's servers</strong>. Also, we don't keep track of download histories of our users, thus making using <a href="https://www.freefbdown.com/" style="color: #2e4193;text-decoration:none;"><b>Free Facebook Video Downloader</b></a> from freefbdown.com totally Anonymous.</p>

              </div>
          </div>
          
      </div>
    <!--/panel-group-->
</div>
</div>


<!-- footer -->
<?php include('includes/footer.php'); ?>

