<?php include('includes/header.php'); ?> 

<div class="body-custom-well">
	<div class="container "> 
		<h1 class="heading-bloger text-center">Privacy Policy</h1>
		<div>
		   <p>If you are thinking to use the https://www.freefbdown.com means you signify your agreement to follow all the terms and conditions set on this page. You are agreed to be bound with the use of this <strong>Facebook Video Downloader</strong> – all applicable <span >rules</span> and regulations and agree that you are responsible for compliance with the laws. </p>
		   <p><br></p>
		   <p>If in case you don’t agree with these rules you are prohibited from using this website. Check Below for the <strong>Terms &amp; Conditions:</strong> </p>
		   <ul >
		      <li>We may change the Terms &amp; Conditions in some period.  We continuously update the revised Terms &amp; Conditions here. You should understand and agree on the services that we provide with the applicable terms and conditions. The acceptance of the updated Terms is constituting your use. </li>
		      <li>This service is independent and in no way associated with Facebook.</li>
		      <li>User is not allowed to download copyrighted content/materials. </li>
		      <li>If you are the owner of content/material and don't want anyone to download your video, then please contact us via email- that is mentioned on the home page. We will block the video download. </li>
		      <li>This downloading service cannot be used to develop a third-party site. If any site is found to use this service remotely will be banned from this service. </li>
		      <li>By using this service, users are not allowed to make the copies or distribute material that downloaded with this software/service. This is for personal use. </li>
		      <li><strong>Download video from Facebook</strong> is users' own risk and All use of the service is at the user's own risk and https://www.freefbdown.com does not take responsibility for the files being downloaded.</li>
		      <li>All the content on this website is copyrighted.</li>
		   </ul>
		   <p><br></p>
		   <p>If you want to download the video from Facebook then Permission is granted to temporarily download one copy of the materials for non-commercial transitory viewing only. </p>
		   <p><br></p>
		   <p>You can’t do such actions: </p>
		   <ul >
		      <li>You can’t modify or copy content. </li>
		      <li>You can't use the material for other commercial purposes. </li>
		      <li>You can’t remove any copyright from any video. </li>
		      <li>You can’t transfer the materials to another person or any other server.</li>
		   </ul>
		   <p>We are committed to conducting these principles to ensure that the confidentiality of any personal information is protected and maintained.</p>
		   <p><br></p>
		   <p><strong>Disclaimer</strong></p>
		   <p>The materials contained in this web site are protected by copyright and law. applicable copyright and trademark law. Further, we don’t warrant or make any representations concerning the accuracy of any Facebook videos. </p>
		   <p><br></p>
		</div>
	</div>
</div>
<?php include('includes/footer.php'); ?>
