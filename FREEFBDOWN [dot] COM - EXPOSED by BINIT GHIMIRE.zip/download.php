<?php

/*
	FREEFBDOWN [dot] COM - EXPOSED by BINIT GHIMIRE
	Facebook Profile: https://www.facebook.com/InternetHeroBINIT
	Facebook Page: https://www.facebook.com/thebinitghimire
	Twitter: @WHOISbinit (https://twitter.com/WHOISBinit)
	LinkedIn: https://www.linkedin.com/in/thebinitghimire
	Official Website: https://binitghimire.com.np
*/

date_default_timezone_set("Asia/Calcutta"); 

if(isset($_REQUEST['src'])){ $file_url = $_REQUEST['src']; }else{ $file_url = base64_decode($_REQUEST['url']); }	
$qlty = $_REQUEST['qlty'];
if(isset($_REQUEST['title']) && $_REQUEST['title'] != '')
{ $file_name=$_REQUEST['title'].'.mp4'; }
else{ 
	if(isset($_REQUEST['src'])){ $file_name=date('Ymdhsi').'_'.$qlty.'_Freefbdown.mp4'; }
	else{ $file_name=date('Ymdhsi').'_Freefbdown.mp4'; }
}

header('Content-Type: application/octet-stream');
header("Content-Transfer-Encoding: Binary");
header("Content-disposition: attachment; filename=\"" .$file_name. "\"");
// header("Content-disposition: attachment; filename=\"" . basename($file_url) . "\"");
readfile($file_url); 
