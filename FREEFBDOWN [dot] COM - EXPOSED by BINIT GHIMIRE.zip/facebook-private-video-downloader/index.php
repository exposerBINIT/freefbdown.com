﻿ 
<?php 
  include('../includes/header.php'); 
?>

<style type="text/css">
	code{
	    padding: 2px 4px;
	    font-size: 92%;
	    color: #224792;
	    background-color: #dddddd7a;
	    border-radius: 0;
	}
	.url-area {
	    width: 100%;
	    padding: 10px;
	    height: 130px;
	    box-shadow: 0 0 19px -5px rgba(0,0,0,.5);
	    border-radius: 7px;
	    border: none;
	    background-color: rgba(255,255,255,.95);
	    color: #474756;
	    font-size: 14px;
	    font-weight: 400;
	    letter-spacing: .8px;
	    background-repeat: no-repeat!important;
	    background-position: center left 20px!important;
	}
</style>

      <div id="loader" class="text-center" style="display: none;"><img src="<?php echo $base_url; ?>/static/img/ajax-loader.gif" /></div>

<div class="body-custom-well">

	<div class="container">
	  <div class="row clearfix">

		  <div class="col-md-12 column">
        <div class="panel panel-default">
          <div class="panel-heading custom_panel_heading">How to download facebook private video?</div>
          <div class="panel-body">            
            <ul>
							<li>Right click on facebook video, and open it in new tab.</li>
							<li>In the URL box, replace <code>www</code> by <code>m</code> from the facebook video URL. </li>
							For eg. if URL is 'https://<b>www</b>.facebook.com/xxx/videos/212506', after you replace 'www' by 'm', it will look something like 'https://<b>m</b>.facebook.com/xxx/videos/212506/' and hit enter.</li>
							<li>Press <code>CTRL+U</code> or <code>⌘+Option+U</code> (if using Mac OS X)to view page source.
							<li>Press <code>CTRL+A</code> or <code>⌘+A</code> to select all and <code>CTRL+C</code> or <code>⌘+Option+C</code> to copy page source.</li>
							<li>Press <code>CTRL+V</code> or <code>⌘+V</code> to paste the page source in below text box and click on "Download".</li>
            </ul>
          </div>
        </div>
  		</div>
  		<div class="clearfix"></div>
  		<div class="col-md-12">
	    	<div class="col-md-2"></div>
	    	<div class="col-md-8 text-center">
					<div style="margin: 15px 0px;">
						<form id="private_vid_down" method="POST">
							<textarea class="url-area" id="source_code" placeholder="Enter source code..." spellcheck="false"></textarea>
							<button type="submit" class="pri_video_down" id="downloadBtn" style="position: unset;margin-top: 8px;background-color: #2e3f91 !important;color: #fff !important;" value="Download"><span class="glyphicon glyphicon-send"></span> &nbsp; Go </span></button>

              <!-- google ad -->
              <div class="text-center" style="background-color: #e4e6f6!important;border: none!important;padding-top: 0px !important;">
                    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                    <ins class="adsbygoogle"
                    style="display:block"
                    data-ad-client="ca-pub-3832212065022513"
                    data-ad-slot="2933578194"
                    data-ad-format="auto"
                    data-full-width-responsive="true"></ins>
                    <script> (adsbygoogle = window.adsbygoogle || []).push({}); </script>
              </div>
              <!-- END google ad -->

              
							<div id="src_div" style="display: none;"></div>
						</form>
			    </div>   
	    	</div>
	    	<div class="col-md-2"></div>
  		</div>
  	</div>
  	
    <div class="col-md-12 text-center">
 			<div class="result_data" style="padding:5% 0 !important;display: none;"></div>
	  </div>
    <div class="clearfix"></div>
    
    <div class="panel panel-default">
      <div class="panel-body">
        <p>Facebook Private Video Downloader is an astounding tool that lets you Download Private Facebook Videos quickly and easily.</p>
        <p>As we all know, there are numerous videos on Facebook that are only visible privately and cannot be downloaded either. And to make it viewable and downloadable to you - Facebook Private Downloader can help.</p>
        <p>Yes, this tool can let you download private videos for free. The downloader is explicitly produced for individuals who are fixated on watching videos on Facebook and are willing to impart to their friends and family.</p>        
        <p>The Best Part? To download Facebook videos with the assistance of this tool, you don't need to install any software or download an application, all you need is to add the source code and enter go, and your video will be downloaded in no time.</p>
        <p>Sharing and watching private Facebook videos was never as easy as it is now.</p>
        <p>What makes Facebook Private Video Downloader Different?</p>
       </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading custom_panel_heading" >Completely Free</div>
      <div class="panel-body">
        <p>Download Private Facebook Videos for Free as our tool is entirely free to use.</p>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading custom_panel_heading" >Easy to use</div>
      <div class="panel-body">
        <p>We have designed this tool with a user interface that is as simple as ABC. You only need to COPY, PASTE & ENTER to download.</p>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading custom_panel_heading" >Work Independently</div>
      <div class="panel-body">
        <p>You don't need to install any software or any application to download videos using this tool. Just open the website, and you are done.</p>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading custom_panel_heading" >Multi-device compatibility</div>
      <div class="panel-body">
        <p>You can download private Facebook videos from any device you wish to as it works on desktop, mobile as well as on tablets.</p>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading custom_panel_heading" >Maintains the Quality</div>
      <div class="panel-body">
        <p>We assure you high quality when you download videos with the assistance of private video downloader</p>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading custom_panel_heading" >How can you download videos with the assistance of Facebook Private Video Downloader?</div>
      <div class="panel-body">
        <ul style="list-style-type: decimal;">
          <li>Click on the Private Video you are willing to download.</li>
          <li>Enter Ctrl + U, with this you will see the page source code.</li>
          <li>Then after, Copy the source code with Ctrl + A & Ctrl + C.</li>
          <li>Paste the Source Code on the text box and click Go!</li> 
        </ul>
        <p>Following these four simple steps will make the magic happen, and your video will be downloaded within a fraction of minutes.</p>
        <p><b>Types of Videos you can Download:</b></p>
        <p>Once you click Go - you will be asked two options to download your video</p>
        <ul style="list-style-type: decimal;">
          <li>Regular & Normal Quality</li>
          <li>HD ( High - Definition) Quality</li>
        </ul>        
        <p>Click the one which you are willing to get, and you are good to go!</p>
        <p><b>Tip: </b>Choosing HD will give you the download that will be similar to the original file.</p>
        <p>Facebook, one of the leading social networks, is well-known for sharing. And these days it is taken as a part of the entertainment as well.  Millions of videos are being uploaded, liked, and shared by people. But the only disadvantage is that it cannot be downloaded.</p>
        <p>And it comes to downloading Facebook videos, you, me and almost all of us are finding ways to download it, share it and view it offline. This is where Facebook Private Video Downloader plays an essential role. As you can now easily Download Private Facebook Videos using this tool.</p>        
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading custom_panel_heading" >Where are all the downloaded videos saved?</div>
      <div class="panel-body">
        <p>All the videos downloaded from Facebook Private Video Downloader will be saved into your default folder which you have kept for your regular downloads as the file works similar to other downloadable items.</p>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading custom_panel_heading" >Does Facebook Private Video Downloader Keep a Copy of the videos?</div>
      <div class="panel-body">
        <p>We guarantee you your security, every video downloaded from Facebook Private Video Downloader is entirely safe and secure, and we do not keep any copies of the videos you download using our tool.</p>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading custom_panel_heading" >Can Facebook Private Video Downloader be used on Mobile Devices?</div>
      <div class="panel-body">
        <p>Our tool is multi-platformed, hence it can be used on all the devices that include desktop, mobile devices as well as tablets.</p>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading custom_panel_heading" >On which operating system this tool works?</div>
      <div class="panel-body">
        <p>You can download private Facebook videos on all the platforms that include Windows, iOS, Android as well as Linux. We've covered it all for you - so no matter what operating system you use - our tool makes downloading Facebook videos just like a cakewalk!</p>
        <p>Facebook Private Video Downloader is all you need if you are willing to download videos from Facebook that are set to private in settings. And the best part is that our tool is entirely free to use and requires no registration process. So, what are you waiting for? ADD, DOWNLOAD PRIVATE FACEBOOK VIDEOS, and SHARE.</p>
      </div>
    </div>

  </div>
</div>

<div id="result_div" style="display: none !important;"></div>

<?php 
  include('../includes/footer.php'); 
?>

<script type="text/javascript">
  $(document).ready(function() {

      $(".pri_video_down").on('click',(function(e) {
          e.preventDefault();             
          $('.result_data').html(''); 
          var source_code = $('#source_code').val();    
          if(source_code==''){ alert('Please enter source code!'); }
          else{
            $('.pri_video_down').attr('disabled',true).html('Loading...');
            $.ajax({
              type: "POST",
              url: '../ajaxdata.php',
              data: {action:'down_private_url',src_code:source_code},
              success: function(result){
                var parse_res = JSON.parse(result);
                var result_div = '';
                if(!parse_res.sd_link && !parse_res.sd_link){
                  result_div='<p class="text-danger" style="font-size: 20px;"><b>Sorry, video not found on given url!</b></p>';
                }else{
                  if(parse_res.sd_link){
                    result_div = '<video controls muted src='+parse_res.sd_link+' class="video-max" width="40%" height="300px" type="video/mp4"></video><div class="clearfix"></div>';
                  }
                  if(parse_res.sd_link){
                    result_div += '<a href="download.php?src='+encodeURIComponent(parse_res.sd_link)+'" class="video_down" id="down_btn"><span class="glyphicon glyphicon-download-alt"></span><b> Download </b></a><div class="clearfix"></div>';
                  }  
                }              
                $('.result_data').html(result_div).show();
                $('#source_code').val(''); 
                $('.pri_video_down').attr('disabled',false).html('<span class="glyphicon glyphicon-send"></span> &nbsp; Go </span>');
                $('html, body').stop().animate({
                    scrollTop: $(".result_data").offset().top
                }, 2000);
              }
            }); 
          }                      
      }));

  }); 

</script>

</body>
</html>
