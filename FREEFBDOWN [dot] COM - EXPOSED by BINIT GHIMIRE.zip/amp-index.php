<?php 

/*
	FREEFBDOWN [dot] COM - EXPOSED by BINIT GHIMIRE
	Facebook Profile: https://www.facebook.com/InternetHeroBINIT
	Facebook Page: https://www.facebook.com/thebinitghimire
	Twitter: @WHOISbinit (https://twitter.com/WHOISBinit)
	LinkedIn: https://www.linkedin.com/in/thebinitghimire
	Official Website: https://binitghimire.com.np
*/

    include('comman.php'); 
    $browser=BrowserWiseExtension(); 
    if($browser=='firefox'){
        $extLink = 'https://addons.mozilla.org/en-US/firefox/addon/video-downloader-for-fb/';
        $extBtnLable = 'Firefox Extension';
        $extImg = 'static/img/Mozilla_Firefox_72-72.png';
    }else{
        $extLink = 'https://chrome.google.com/webstore/detail/freefbdown-video-download/epkpmkghpohjnpojfnjkgpnhbmjbbiik';
        $extBtnLable='Chrome Extension';
        $extImg = 'static/img/chrome.png';    
    }
    $base_url=(isset($_SERVER['HTTPS'])&&$_SERVER['HTTPS']==='on'?"https":"http")."://$_SERVER[HTTP_HOST]";
    $actual_link=(isset($_SERVER['HTTPS'])&&$_SERVER['HTTPS']==='on'?"https":"http")."://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

?>

<!DOCTYPE html> 
<html amp lang="en" itemscope itemtype="http://schema.org/WebPage">  
    <head>
        <meta name="geo.region" content="IN-GJ" />
        <meta name="geo.placename" content="Ahmedabad" />
        <meta name="geo.position" content="23.021624;72.579707" />
        <meta name="ICBM" content="23.021624, 72.579707" />
        <meta name="classification" content="Facebook Video Downloader" />
        <meta name="language" content="English" />
        <meta name="GOOGLEBOT" content="index, follow" />
        <meta name="Robots" content="index, follow" />
        <meta name="Search Engine" content="https://www.Google.com" />
        <meta name="OWNER" content="Facebook Video Downloader" />
        <meta name="author" content="Facebook Video Downloader" />
        <meta name="copyright" content="Facebook Video Downloader" /> 
        <meta name="expires" content="Never" />
        <meta name="RATING" content="General" />

        <meta charset="utf-8">  
        <title>Facebook Video Downloader | Download Facebook Videos Online from Freefbdown.com</title>
        <meta name="description" content="Facebook Video Downloader Online, Freefbdown.com is the free website for download video from facebook online. Download facebook videos from facebook to your computer or mobile for Free.">
        <meta name="keywords" content="Free Facebook Video Downloader, Online Facebook Video Downloader, Facebook Video Downloader Online, Download Facebook Videos Free, Facebook Video Downloader, Online tool for Facebook Video Downloader, Best Online tool facebook Video Downloader, Online tool for Facebook Video Downloader">
        <meta name="google-site-verification" content="HhfHjyP-TLAolLoiXfGiX_WxQu03akpfhdCvKPBgA4E" />
        <meta name="author" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=3">

        <!-- meta tag for facebook -->
        <meta property="fb:app_id" content="2221189334769023">
        <link rel="image_src" type="image/png" href="<?php echo $base_link.'/static/img/logo/video_downloader.png'; ?>">
        <meta property="og:type" content="website">
        <meta property="og:site_name" content="freefbdown.com"/>
        <meta property="og:url" content="<?php echo $base_link; ?>"/>
        <meta property="og:title" content="Freefbdown - video downloader" /> 
        <meta property="og:description" content="Download Facebook Videos, Download Video HD MP4 and Save them directly from facebook to your mobile or computer in HD and MP4." />   
        <meta property="og:image" content="<?php echo $base_link.'/static/img/logo/video_downloader.png'; ?>" />
        <meta property="og:image:width" content="400" />
        <meta property="og:image:height" content="300" />
        <!-- <meta name="amp-experiments-opt-in" content="experiment-a,experiment-b"> -->
        
        <!-- meta tag for twitter -->
        <meta property="twitter:image" content="<?php echo $base_link.'/static/img/logo/video_downloader.png'; ?>" />
        <meta itemprop="name" content="Download Facebook Videos, Download Video HD MP4 and Save them directly from facebook to your mobile or computer in HD and MP4.">
        <meta itemprop="description" content="Download Facebook Videos, Download Video HD MP4 and Save them directly from facebook to your mobile or computer in HD and MP4.">
        <link rel="amphtml" href="<?php echo $actual_link; ?>">
        <link rel="canonical" href="<?php echo $actual_link; ?>" /> 
        <link rel="alternate" href="<?php echo $actual_link; ?>" hreflang="x-default" />
        <link rel="shortcut icon" href="static/img/logo/video_down_favicon.ico" type="image/x-icon">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,700italic,400,300,700" rel="stylesheet">
        <style amp-custom>
            html{font-family:sans-serif;-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%}
            body{margin:0}article,aside,details,figcaption,figure,footer,header,hgroup,main,menu,nav,section,summary{display:block}a{background-color:transparent}a:active,a:hover{outline:0}b,strong{font-weight:700}h1{font-size:2em;margin:.67em 0}img{border:0}svg:not(:root){overflow:hidden}figure{margin:1em 40px}hr{-moz-box-sizing:content-box;-webkit-box-sizing:content-box;box-sizing:content-box;height:0}button,input,optgroup,select,textarea{color:inherit;font:inherit;margin:0}button{overflow:visible}button,select{text-transform:none}button,html input[type=button],input[type=reset],input[type=submit]{-webkit-appearance:button;cursor:pointer}button[disabled],html input[disabled]{cursor:default}button::-moz-focus-inner,input::-moz-focus-inner{border:0;padding:0}input{line-height:normal}@media print{*,:after,:before{background:0 0;color:#000;-webkit-box-shadow:none;box-shadow:none;text-shadow:none}a,a:visited{text-decoration:underline}a[href]:after{content:" (" attr(href) ")"}abbr[title]:after{content:" (" attr(title) ")"}a[href^="#"]:after,a[href^="javascript:"]:after{content:""}blockquote,pre{border:1px solid #999;page-break-inside:avoid}thead{display:table-header-group}img,tr{page-break-inside:avoid}img{max-width:100%}h2,h3,p{orphans:3;widows:3}h2,h3{page-break-after:avoid}select{background:#fff}.navbar{display:none}.btn>.caret,.dropup>.btn>.caret{border-top-color:#000}.label{border:1px solid #000}.table{border-collapse:collapse}.table td,.table th{background-color:#fff}.table-bordered td,.table-bordered th{border:1px solid #ddd}}@font-face{font-family:'Glyphicons Halflings';src:url(static/fonts/glyphicons-halflings-regular.eot);src:url(static/fonts/glyphicons-halflings-regular.eot?#iefix) format('embedded-opentype'),url(static/fonts/glyphicons-halflings-regular.woff) format('woff'),url(static/fonts/glyphicons-halflings-regular.ttf) format('truetype'),url(static/fonts/glyphicons-halflings-regular.svg#glyphicons_halflingsregular) format('svg')}.glyphicon{position:relative;top:1px;display:inline-block;font-family:'Glyphicons Halflings';font-style:normal;font-weight:400;line-height:1;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.glyphicon-time:before{content:"\e023"}.glyphicon-road:before{content:"\e024"}.glyphicon-download-alt:before{content:"\e025"}.glyphicon-download:before{content:"\e026"}.glyphicon-ok-sign:before{content:"\e084"}.glyphicon-question-sign:before{content:"\e085"}.glyphicon-info-sign:before{content:"\e086"}*{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}:after,:before{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}html{font-size:10px;-webkit-tap-highlight-color:transparent}body{font-family:"Open Sans","Helvetica Neue",Helvetica,Arial,sans-serif;font-size:15px;line-height:1.4;color:#222;background-color:#fff}button,input,select,textarea{font-family:inherit;font-size:inherit;line-height:inherit}a{color:#008cba;text-decoration:none}a:focus,a:hover{color:#00526e;text-decoration:underline}a:focus{outline:thin dotted;outline:5px auto -webkit-focus-ring-color;outline-offset:-2px}figure{margin:0}img{vertical-align:middle}.carousel-inner>.item>a>img,.carousel-inner>.item>img,.img-responsive,.thumbnail a>img,.thumbnail>img{display:block;max-width:100%;height:auto}.img-rounded{border-radius:0}.img-thumbnail{padding:4px;line-height:1.4;background-color:#fff;border:1px solid #ddd;border-radius:0;-webkit-transition:all .2s ease-in-out;-o-transition:all .2s ease-in-out;transition:all .2s ease-in-out;display:inline-block;max-width:100%;height:auto}.img-circle{border-radius:50%}hr{margin-top:21px;margin-bottom:21px;border:0;border-top:1px solid #ddd}.sr-only{position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0,0,0,0);border:0}.sr-only-focusable:active,.sr-only-focusable:focus{position:static;width:auto;height:auto;margin:0;overflow:visible;clip:auto}.h1,.h2,.h3,.h4,.h5,.h6,h1,h2,h3,h4,h5,h6{font-family:"Open Sans","Helvetica Neue",Helvetica,Arial,sans-serif;font-weight:300;line-height:1.1;color:inherit}.h1,.h2,.h3,h1,h2,h3{margin-top:21px;margin-bottom:10.5px}.h4,.h5,.h6,h4,h5,h6{margin-top:10.5px;margin-bottom:10.5px}.h1,h1{font-size:39px}.h2,h2{font-size:32px}.h3,h3{font-size:26px}.h4,h4{font-size:19px}.h5,h5{font-size:15px}.h6,h6{font-size:13px}p{margin:0 0 10.5px}.text-left{text-align:left}.text-right{text-align:right}.text-center{text-align:center}.text-justify{text-align:justify}.text-nowrap{white-space:nowrap}.text-lowercase{text-transform:lowercase}.text-uppercase{text-transform:uppercase}.text-capitalize{text-transform:capitalize}.page-header{padding-bottom:9.5px;margin:42px 0 21px;border-bottom:1px solid #ddd}ol,ul{margin-top:0;margin-bottom:10.5px}ol ol,ol ul,ul ol,ul ul{margin-bottom:0}.list-unstyled{padding-left:0;list-style:none}.list-inline{padding-left:0;list-style:none;margin-left:-5px}.list-inline>li{display:inline-block;padding-left:5px;padding-right:5px}.container{margin-right:auto;margin-left:auto;padding-left:15px;padding-right:15px}@media (min-width:768px){.container{width:750px}}@media (min-width:992px){.container{width:970px}}@media (min-width:1200px){.container{width:1170px}}.container-fluid{margin-right:auto;margin-left:auto;padding-left:15px;padding-right:15px}.row{margin-left:-15px;margin-right:-15px}.col-lg-1,.col-lg-10,.col-lg-11,.col-lg-12,.col-lg-2,.col-lg-3,.col-lg-4,.col-lg-5,.col-lg-6,.col-lg-7,.col-lg-8,.col-lg-9,.col-md-1,.col-md-10,.col-md-11,.col-md-12,.col-md-2,.col-md-3,.col-md-4,.col-md-5,.col-md-6,.col-md-7,.col-md-8,.col-md-9,.col-sm-1,.col-sm-10,.col-sm-11,.col-sm-12,.col-sm-2,.col-sm-3,.col-sm-4,.col-sm-5,.col-sm-6,.col-sm-7,.col-sm-8,.col-sm-9,.col-xs-1,.col-xs-10,.col-xs-11,.col-xs-12,.col-xs-2,.col-xs-3,.col-xs-4,.col-xs-5,.col-xs-6,.col-xs-7,.col-xs-8,.col-xs-9{position:relative;min-height:1px;padding-left:15px;padding-right:15px}.col-xs-1,.col-xs-10,.col-xs-11,.col-xs-12,.col-xs-2,.col-xs-3,.col-xs-4,.col-xs-5,.col-xs-6,.col-xs-7,.col-xs-8,.col-xs-9{float:left}.col-xs-12{width:100%}.col-xs-11{width:91.66666667%}.col-xs-10{width:83.33333333%}.col-xs-9{width:75%}.col-xs-8{width:66.66666667%}.col-xs-7{width:58.33333333%}.col-xs-6{width:50%}.col-xs-5{width:41.66666667%}.col-xs-4{width:33.33333333%}.col-xs-3{width:25%}.col-xs-2{width:16.66666667%}.col-xs-1{width:8.33333333%}@media (min-width:768px){.col-sm-1,.col-sm-10,.col-sm-11,.col-sm-12,.col-sm-2,.col-sm-3,.col-sm-4,.col-sm-5,.col-sm-6,.col-sm-7,.col-sm-8,.col-sm-9{float:left}.col-sm-12{width:100%}.col-sm-11{width:91.66666667%}.col-sm-10{width:83.33333333%}.col-sm-9{width:75%}.col-sm-8{width:66.66666667%}.col-sm-7{width:58.33333333%}.col-sm-6{width:50%}.col-sm-5{width:41.66666667%}.col-sm-4{width:33.33333333%}.col-sm-3{width:25%}.col-sm-2{width:16.66666667%}.col-sm-1{width:8.33333333%}}@media (min-width:992px){.col-md-1,.col-md-10,.col-md-11,.col-md-12,.col-md-2,.col-md-3,.col-md-4,.col-md-5,.col-md-6,.col-md-7,.col-md-8,.col-md-9{float:left}.col-md-12{width:100%}.col-md-11{width:91.66666667%}.col-md-10{width:83.33333333%}.col-md-9{width:75%}.col-md-8{width:66.66666667%}.col-md-7{width:58.33333333%}.col-md-6{width:50%}.col-md-5{width:41.66666667%}.col-md-4{width:33.33333333%}.col-md-3{width:25%}.col-md-2{width:16.66666667%}.col-md-1{width:8.33333333%}}@media (min-width:1200px){.col-lg-1,.col-lg-10,.col-lg-11,.col-lg-12,.col-lg-2,.col-lg-3,.col-lg-4,.col-lg-5,.col-lg-6,.col-lg-7,.col-lg-8,.col-lg-9{float:left}.col-lg-12{width:100%}.col-lg-11{width:91.66666667%}.col-lg-10{width:83.33333333%}.col-lg-9{width:75%}.col-lg-8{width:66.66666667%}.col-lg-7{width:58.33333333%}.col-lg-6{width:50%}.col-lg-5{width:41.66666667%}.col-lg-4{width:33.33333333%}.col-lg-3{width:25%}.col-lg-2{width:16.66666667%}.col-lg-1{width:8.33333333%}}input[type=button].btn-block,input[type=reset].btn-block,input[type=submit].btn-block{width:100%}.fade{opacity:0;-webkit-transition:opacity .15s linear;-o-transition:opacity .15s linear;transition:opacity .15s linear}.fade.in{opacity:1}.collapse{display:none;visibility:hidden}.collapse.in{display:block;visibility:visible}tr.collapse.in{display:table-row}tbody.collapse.in{display:table-row-group}.collapsing{position:relative;height:0;overflow:hidden;-webkit-transition-property:height,visibility;-o-transition-property:height,visibility;transition-property:height,visibility;-webkit-transition-duration:.35s;-o-transition-duration:.35s;transition-duration:.35s;-webkit-transition-timing-function:ease;-o-transition-timing-function:ease;transition-timing-function:ease}.caret{display:inline-block;width:0;height:0;margin-left:2px;vertical-align:middle;border-top:4px solid;border-right:4px solid transparent;border-left:4px solid transparent}.dropdown{position:relative}.dropdown-toggle:focus{outline:0}.dropdown-menu{position:absolute;top:100%;left:0;z-index:1000;display:none;float:left;min-width:160px;padding:5px 0;margin:2px 0 0;list-style:none;font-size:15px;text-align:left;background-color:#fff;border:1px solid #ccc;border:1px solid rgba(0,0,0,.15);border-radius:0;-webkit-box-shadow:0 6px 12px rgba(0,0,0,.175);box-shadow:0 6px 12px rgba(0,0,0,.175);-webkit-background-clip:padding-box;background-clip:padding-box}.dropdown-menu.pull-right{right:0;left:auto}.dropdown-menu .divider{height:1px;margin:9.5px 0;overflow:hidden;background-color:rgba(0,0,0,.2)}.dropdown-menu>li>a{display:block;padding:3px 20px;clear:both;font-weight:400;line-height:1.4;color:#555;white-space:nowrap}.dropdown-menu>li>a:focus,.dropdown-menu>li>a:hover{text-decoration:none;color:#262626;background-color:#eee}.dropdown-menu>.active>a,.dropdown-menu>.active>a:focus,.dropdown-menu>.active>a:hover{color:#fff;text-decoration:none;outline:0;background-color:#008cba}.dropdown-menu>.disabled>a,.dropdown-menu>.disabled>a:focus,.dropdown-menu>.disabled>a:hover{color:#999}.dropdown-menu>.disabled>a:focus,.dropdown-menu>.disabled>a:hover{text-decoration:none;background-color:transparent;background-image:none;cursor:not-allowed}.open>.dropdown-menu{display:block}.open>a{outline:0}.dropdown-menu-right{left:auto;right:0}.dropdown-menu-left{left:0;right:auto}.dropdown-header{display:block;padding:3px 20px;font-size:12px;line-height:1.4;color:#999;white-space:nowrap}.dropdown-backdrop{position:fixed;left:0;right:0;bottom:0;top:0;z-index:990}.pull-right>.dropdown-menu{right:0;left:auto}.dropup .caret,.navbar-fixed-bottom .dropdown .caret{border-top:0;border-bottom:4px solid;content:""}.dropup .dropdown-menu,.navbar-fixed-bottom .dropdown .dropdown-menu{top:auto;bottom:100%;margin-bottom:1px}.nav{margin-bottom:0;padding-left:0;list-style:none}.nav>li{position:relative;display:block}.nav>li>a{position:relative;display:block;padding:10px 15px}.nav>li>a:focus,.nav>li>a:hover{text-decoration:none;background-color:#eee}.nav>li.disabled>a{color:#999}.nav>li.disabled>a:focus,.nav>li.disabled>a:hover{color:#999;text-decoration:none;background-color:transparent;cursor:not-allowed}.nav .open>a,.nav .open>a:focus,.nav .open>a:hover{background-color:#eee;border-color:#008cba}.nav .nav-divider{height:1px;margin:9.5px 0;overflow:hidden;background-color:#e5e5e5}.nav>li>a>img{max-width:none}.list-group{margin-bottom:20px;padding-left:0}.panel{margin-bottom:21px;background-color:#fff;border:1px solid transparent;border-radius:0;-webkit-box-shadow:0 1px 1px rgba(0,0,0,.05);box-shadow:0 1px 1px rgba(0,0,0,.05)}.panel-body{padding:15px}.panel-heading{padding:10px 15px;border-bottom:1px solid transparent;border-top-right-radius:-1;border-top-left-radius:-1}.panel-heading>.dropdown .dropdown-toggle{color:inherit}.panel-title{margin-top:0;margin-bottom:0;font-size:17px;color:inherit}.panel-title>a{color:inherit}.panel-footer{padding:10px 15px;background-color:#f5f5f5;border-top:1px solid #ddd;border-bottom-right-radius:-1;border-bottom-left-radius:-1}.list-group+.panel-footer{border-top-width:0}.panel>.panel-collapse>.table,.panel>.table,.panel>.table-responsive>.table{margin-bottom:0}.panel>.panel-collapse>.table caption,.panel>.table caption,.panel>.table-responsive>.table caption{padding-left:15px;padding-right:15px}.panel>.table-responsive:first-child>.table:first-child,.panel>.table:first-child{border-top-right-radius:-1;border-top-left-radius:-1}.panel-group{margin-bottom:21px}.panel-group .panel{margin-bottom:0;border-radius:0}.panel-group .panel+.panel{margin-top:5px}.panel-group .panel-heading{border-bottom:0}.panel-group .panel-heading+.panel-collapse>.list-group,.panel-group .panel-heading+.panel-collapse>.panel-body{border-top:1px solid #ddd}.panel-group .panel-footer{border-top:0}.panel-group .panel-footer+.panel-collapse .panel-body{border-bottom:1px solid #ddd}.panel-default{border-color:#ddd}.panel-default>.panel-heading{color:#333;background-color:#f5f5f5;border-color:#ddd}.panel-default>.panel-heading+.panel-collapse>.panel-body{border-top-color:#ddd}.panel-default>.panel-heading .badge{color:#f5f5f5;background-color:#333}.panel-default>.panel-footer+.panel-collapse>.panel-body{border-bottom-color:#ddd}.panel-primary{border-color:#008cba}.panel-primary>.panel-heading{color:#fff;background-color:#008cba;border-color:#008cba}.panel-primary>.panel-heading+.panel-collapse>.panel-body{border-top-color:#008cba}.panel-primary>.panel-heading .badge{color:#008cba;background-color:#fff}.panel-primary>.panel-footer+.panel-collapse>.panel-body{border-bottom-color:#008cba}.panel-success{border-color:#3c9a5f}.panel-success>.panel-heading{color:#fff;background-color:#43ac6a;border-color:#3c9a5f}.panel-success>.panel-heading+.panel-collapse>.panel-body{border-top-color:#3c9a5f}.panel-success>.panel-heading .badge{color:#43ac6a;background-color:#fff}.panel-success>.panel-footer+.panel-collapse>.panel-body{border-bottom-color:#3c9a5f}.panel-info{border-color:#3db5d8}.panel-info>.panel-heading{color:#fff;background-color:#5bc0de;border-color:#3db5d8}.panel-info>.panel-heading+.panel-collapse>.panel-body{border-top-color:#3db5d8}.panel-info>.panel-heading .badge{color:#5bc0de;background-color:#fff}.panel-info>.panel-footer+.panel-collapse>.panel-body{border-bottom-color:#3db5d8}.panel-warning{border-color:#d08002}.panel-warning>.panel-heading{color:#fff;background-color:#e99002;border-color:#d08002}.panel-warning>.panel-heading+.panel-collapse>.panel-body{border-top-color:#d08002}.panel-warning>.panel-heading .badge{color:#e99002;background-color:#fff}.panel-warning>.panel-footer+.panel-collapse>.panel-body{border-bottom-color:#d08002}.panel-danger{border-color:#ea2f10}.panel-danger>.panel-heading{color:#fff;background-color:#f04124;border-color:#ea2f10}.panel-danger>.panel-heading+.panel-collapse>.panel-body{border-top-color:#ea2f10}.panel-danger>.panel-heading .badge{color:#f04124;background-color:#fff}.panel-danger>.panel-footer+.panel-collapse>.panel-body{border-bottom-color:#ea2f10}.pull-right{float:right}.pull-left{float:left}.hide{display:none}.show{display:block}.invisible{visibility:hidden}.text-hide{font:0/0 a;color:transparent;text-shadow:none;background-color:transparent;border:0}.hidden{display:none;visibility:hidden}table{font-size:12px}.list-group{font-size:12px;font-weight:300}.dropdown-menu{padding:0;margin-top:0;font-size:12px}.dropdown-menu>li>a{padding:12px 15px}.dropdown-header{padding-left:15px;padding-right:15px;font-size:9px;text-transform:uppercase}.panel-footer,.panel-heading{border-top-right-radius:0;border-top-left-radius:0}.modal .close{color:#222}
            /* custom.css */
            #downloadForm,.preview{position:relative}.centered{text-align:center;width:90%;margin:0 auto}#vid_url{word-break:break-all}.upper-display{background:#099}.purple-bg{background:teal}#navMenu{display:block;overflow:hidden;padding:20px 55px;margin:0 auto}#navMenu .logo{margin:0;padding:0;text-align:center}#navMenu .logo a{font-weight:600;font-size:26px;color:#fff;text-decoration:none;letter-spacing:.3px}.upper-display .header{color:#fff;text-align:center;max-width:1100px;margin:0 auto;padding:45px 10px}.upper-display .header h2{font-weight:400;font-size:20px}.searchForm{padding:0 15px 50px;max-width:700px;margin:0 auto}.downloadSection{text-align:center;margin-top:50px;margin-bottom:50px;padding:0 15px}.downloadSection img{display:block;margin:0 auto 16.75px;border:1px solid #c5c5c5;width:100%;max-width:350px}.front-main{padding:0 15px;max-width:900px;margin:0 auto;text-align:center}.site-selection h2{font-size:30px;font-weight:400;color:#223254e6;margin-bottom:50px}.site-selection .site{margin-bottom:30px}.preview{background:#fdfdfd;border-radius:4px;min-height:100px;box-shadow:0 0 1px 1px rgba(21,37,72,.11);margin-bottom:10px}.preview img{width:50px;position:absolute;top:0;bottom:0;right:0;left:0;margin:auto}.site-selection .site span{text-align:center;color:#223254e6;text-decoration:none;font-weight:700}.pBtn,.pBtn:hover{color:#fff;text-decoration:none}.pBtn{background:#6a2884;font-size:15px;font-weight:500;padding:15px;border-radius:3px;display:block;width:250px;margin:20px auto 0}.pBtn:hover{background:teal}.page-title-wrap{padding-bottom:35px;padding-top:35px;margin:20px auto 40px;width:100%;display:table;padding:15px 0;-moz-box-shadow:3px 3px 5px 6px #ccc;-webkit-box-shadow:3px 3px 5px 6px #ccc;box-shadow:3px 3px 5px 6px #ccc}.header-main-bg{margin-bottom:0;background-color:#2e4193;border-bottom:2px solid #3257a2;height:auto;width:100%;padding:10px 0;position:fixed}.logo-ahref img{max-width:160px;width:100%}.navbar-nav{float:right;margin:0}.dropdown-menu>li>a{padding:8px 15px;border-bottom:1px solid #eee}.slider-show,.slider-show-inner{display:table;position:relative}.slider-show{min-height:450px;width:100%;background-size:cover;background-attachment:fixed;padding:80px 0 40px;background-image:linear-gradient(to right top,#310069,#2f1e7a,#2e3389,#2e4596,#3257a2)}.slider-show-inner{vertical-align:middle;z-index:0;color:#fff;opacity:1;margin:0 auto;max-width:1170px;padding:60px 0}.caret,footer ul li{display:inline-block}.slider-show::before{width:100%;height:100%;position:absolute;content:""}.slider-show-inner .header h1{text-align:center;font-size:42px;font-weight:600}.slider-show-inner .header h2{text-align:center;margin:0 auto 20px}.dropdown-menu{left:auto;right:0}.caret{width:0;height:0;margin-left:8px;margin-top:-3px;vertical-align:middle;border-top:5px solid;border-right:5px solid transparent;border-left:5px solid transparent}#downloadBtn{border:none;position:absolute;right:0;top:0;background:#d8deec;color:#2e3c90;font-weight:700;line-height:60px;width:150px;cursor:pointer;text-align:center;height:60px;border-radius:0 3px 3px 0;transition:.3s all}#downloadBtn:hover{transition:.5s all;background:#0e1c70;color:#fff}.url-input{width:100%;padding-right:15px;height:60px;box-shadow:0 0 19px -5px rgba(0,0,0,.5);border-radius:7px;border:none;background-color:rgba(255,255,255,.95);padding-left:65px;color:#474756;font-size:14px;font-weight:400;letter-spacing:.8px;background-image:url(https://pickvideo.net/img/input-icon.svg);background-repeat:no-repeat;background-position:center left 20px;text-transform:uppercase}footer{background:#2e4193;padding:10px 0 0;color:#ccc;font-size:12px;text-align:center}footer ul{list-style:none;padding:15px 0;margin:0;text-align:center}footer ul li{padding:0 5px}footer ul li a{color:#fff;font-size:14px;letter-spacing:.5px;padding:0 3px}footer ul li a:hover{color:#edecec;text-decoration:none}.copyright{background:#263781;padding:10px;margin-top:7px;color:#d5d5d5;letter-spacing:1px}#sticky-wrapper{position:absolute;z-index:999}.is-sticky nav{background:rgba(255,255,255,.9);z-index:999;display:table}.left-logo{float:left}.panel-default>.panel-heading{color:#304e9c;background-color:#f5f5f5;border-color:#d8deec}.panel-default{border-color:#d8deec}.align-text-dec h2{font-size:30px;font-weight:400;margin:40px auto 20px;color:#2e4394}.align-text-dec p{font-size:14px;margin:0 auto 15px}.slider-show-had{position:relative;display:table;width:100%;background-size:cover;background-attachment:fixed;height:70px;background-image:linear-gradient(to right top,#310069,#2f1e7a,#2e3389,#2e4596,#3257a2)}.text-dec h4{font-size:19px;font-weight:700;color:#2f4798;text-transform:unset}.video-max{max-width:500px;border:7px solid #c4cde0}.custom-well{min-height:20px;background-color:#e4e6f6;border:none;-webkit-box-shadow:inset 0 1px 1px rgba(0,0,0,.05);box-shadow:inset 0 1px 1px rgba(0,0,0,.05);margin-bottom:0;padding-bottom:40px;padding-top:40px}.col-xs-12.col-md-8.text-dec{padding:0}.red-error{color:red;font-weight:500;background:#fee3e3;padding:25px;font-size:25px;display:table;letter-spacing:.3px;margin:30px}.margin-btm{margin:0 auto 20px}.max-box-td{max-width:470px;margin:0 auto}.display-logo{display:block}.hide-logo,.is-sticky .display-logo{display:none}.is-sticky .hide-logo{display:block}@media only screen and (max-width:767px){.navbar-nav{float:right;margin:0;width:100%}.navbar-default .navbar-nav>li>a,.navbar-default .navbar-nav>li>a:hover{color:#224792;font-size:15px;font-weight:500;background-color:#fff;box-shadow:none;padding:10px 25px;margin-top:4px}.caret{float:right;margin:7px}#sticky-wrapper{position:absolute;z-index:999;background:#2f4999}.navbar-toggle{margin-right:0}.slider-show-inner .header h1{text-align:center;font-size:25px;font-weight:600}.slider-show-inner .header h2{text-align:center;margin:0 auto 20px;font-size:15px}#downloadBtn{width:52px;overflow:hidden}.url-input{width:100%;padding-right:15px;height:60px;box-shadow:0 0 19px -5px rgba(0,0,0,.5);border-radius:7px;border:none;background-color:rgba(255,255,255,.95);padding-left:43px;color:#474756;font-size:14px;font-weight:400;letter-spacing:.8px;background-image:url(https://pickvideo.net/img/input-icon.svg);background-repeat:no-repeat;background-position:center left 14px;text-transform:uppercase;background-size:24px}.is-sticky .navbar-default .navbar-toggle .icon-bar{background-color:#30509d}.left-logo{float:left;width:100%}}.slider-show-inner.width-full{width:100%}.img-full-btn{max-width:135px;background:#ffffff61;border-radius:8px;border:1px solid #fff}.max-width-full{max-width:685px}@font-face{font-family:'Open Sans';font-style:normal;font-weight:400;src:local('Open Sans Regular'),local('OpenSans-Regular'),url(https://fonts.gstatic.com/s/opensans/v16/mem8YaGs126MiZpBA-UFWJ0bf8pkAp6a.woff2) format('woff2')}
            /* attached-css.css */
            .ext_img{width:17px}.url-input{text-transform:none}.fb_like{margin:2% 0}.custom_panel_heading{color:#2e4596;font-size:20px}.panel-body a{color:#2e4193;text-decoration:none}.panel-body p{text-align:justify}#menu>ul>li{margin:2px}#downloadForm,.preview{position:relative;margin-bottom:1.5%}.searchForm{padding:0;max-width:700px;margin:0 auto}.howtouse_section p{text-align:center}.howtouse_section h4{color:#2f2f2fe6;font-weight:700}
            /* custom css for logo */
            @media (max-width: 667px){ amp-img.logo_media { max-width: 52px ; }} 
            amp-social-share.rounded { border-radius: 50%;background-size: 60%;color: #fff;}
            /* Custom css for menu as well as sidebar */
            .text-decoration-none{text-decoration:none}.left-align{text-align:left}.center{text-align:center}.right-align{text-align:right}.justify{text-align:justify}.nowrap{white-space:nowrap}.break-word{word-wrap:break-word}.list-reset{list-style:none;padding-left:0}.m0{margin:0}.mt0{margin-top:0}.mr0{margin-right:0}.mb0{margin-bottom:0}.ml0,.mx0{margin-left:0}.mx0{margin-right:0}.my0{margin-top:0;margin-bottom:0}.m1{margin:1rem}.mt1{margin-top:1rem}.mr1{margin-right:1rem}.mb1{margin-bottom:1rem}.ml1,.mx1{margin-left:1rem}.mx1{margin-right:1rem}.my1{margin-top:1rem;margin-bottom:1rem}.m2{margin:1.5rem}.mt2{margin-top:1.5rem}.mr2{margin-right:1.5rem}.mb2{margin-bottom:1.5rem}.ml2,.mx2{margin-left:1.5rem}.mx2{margin-right:1.5rem}.my2{margin-top:1.5rem;margin-bottom:1.5rem}.m3{margin:2rem}.mt3{margin-top:2rem}.mr3{margin-right:2rem}.mb3{margin-bottom:2rem}.ml3,.mx3{margin-left:2rem}.mx3{margin-right:2rem}.my3{margin-top:2rem;margin-bottom:2rem}.m4{margin:2.5rem}.mt4{margin-top:2.5rem}.mr4{margin-right:2.5rem}.mb4{margin-bottom:2.5rem}.ml4,.mx4{margin-left:2.5rem}.mx4{margin-right:2.5rem}.my4{margin-top:2.5rem;margin-bottom:2.5rem}.m-auto{margin:auto}.mt-auto{margin-top:auto}.mr-auto{margin-right:auto}.mb-auto{margin-bottom:auto}.ml-auto,.mx-auto{margin-left:auto}.mx-auto{margin-right:auto}.my-auto{margin-top:auto;margin-bottom:auto}.p0{padding:0}.pt0{padding-top:0}.pr0{padding-right:0}.pb0{padding-bottom:0}.pl0,.px0{padding-left:0}.px0{padding-right:0}.py0{padding-top:0;padding-bottom:0}.p1{padding:1rem}.pt1{padding-top:1rem}.pr1{padding-right:1rem}.pb1{padding-bottom:1rem}.pl1{padding-left:1rem}.py1{padding-top:1rem;padding-bottom:1rem}.px1{padding-left:1rem;padding-right:1rem}.p2{padding:1.5rem}.pt2{padding-top:1.5rem}.pr2{padding-right:1.5rem}.pb2{padding-bottom:1.5rem}.pl2{padding-left:1.5rem}.py2{padding-top:1.5rem;padding-bottom:1.5rem}.px2{padding-left:1.5rem;padding-right:1.5rem}.p3{padding:2rem}.pt3{padding-top:2rem}.pr3{padding-right:2rem}.pb3{padding-bottom:2rem}.pl3{padding-left:2rem}.py3{padding-top:2rem;padding-bottom:2rem}.px3{padding-left:2rem;padding-right:2rem}.p4{padding:2.5rem}.pt4{padding-top:2.5rem}.pr4{padding-right:2.5rem}.pb4{padding-bottom:2.5rem}.pl4{padding-left:2.5rem}.py4{padding-top:2.5rem;padding-bottom:2.5rem}.px4{padding-left:2.5rem;padding-right:2.5rem}.flex{display:-ms-flexbox;display:flex}@media (min-width:40.06rem){.sm-flex{display:-ms-flexbox;display:flex}}@media (min-width:52.06rem){.md-flex{display:-ms-flexbox;display:flex}}@media (min-width:64.06rem){.lg-flex{display:-ms-flexbox;display:flex}}.flex-column{-ms-flex-direction:column;flex-direction:column}.flex-wrap{-ms-flex-wrap:wrap;flex-wrap:wrap}.flex-none{-ms-flex:none;flex:none}.relative{position:relative}.absolute{position:absolute}.fixed{position:fixed}.top-0{top:0}.right-0{right:0}.bottom-0{bottom:0}.left-0{left:0}.z1{z-index:1}.z2{z-index:2}.z3{z-index:3}.z4{z-index:4}.hide{position:absolute;height:1px;width:1px;overflow:hidden;clip:rect(1px,1px,1px,1px)}@media (max-width:40rem){.xs-hide{display:none}}@media (min-width:40.06rem) and (max-width:52rem){.sm-hide{display:none}}@media (min-width:52.06rem) and (max-width:64rem){.md-hide{display:none}}@media (min-width:64.06rem){.lg-hide{display:none}}.display-none{display:none}*{box-sizing:border-box}#content:target{margin-top:calc(0px - 3.5rem);padding-top:3.5rem}.ampstart-headerbar{background-color:#fff;color:#000;z-index:999;box-shadow:0 0 5px 2px rgba(0,0,0,.1)}.ampstart-headerbar+:not(amp-sidebar),.ampstart-headerbar+amp-sidebar+*{margin-top:3.5rem}.ampstart-headerbar-nav .ampstart-nav-item{padding:0;background:transparent;}.ampstart-headerbar-nav{line-height:3.5rem}.ampstart-nav-item:active,.ampstart-nav-item:focus,.ampstart-nav-item:hover{opacity:1}.ampstart-navbar-trigger:focus{outline:none}.ampstart-nav a,.ampstart-navbar-trigger,.ampstart-sidebar-faq a{cursor:pointer;text-decoration:none}.ampstart-nav .ampstart-label{color:inherit}.ampstart-navbar-trigger{line-height:3.5rem;font-size:2rem}.ampstart-headerbar-nav{-ms-flex:1;flex:1}.ampstart-nav-search{-ms-flex-positive:0.5;flex-grow:0.5}.ampstart-headerbar .ampstart-nav-search:active,.ampstart-headerbar .ampstart-nav-search:focus,.ampstart-headerbar .ampstart-nav-search:hover{box-shadow:none}.ampstart-nav-search>input{border:none;border-radius:3px;line-height:normal}.ampstart-nav-dropdown{min-width:150px}.ampstart-nav-dropdown amp-accordion header{background-color:#fff;border:none}.ampstart-nav-dropdown amp-accordion ul{background-color:#fff}.ampstart-nav-dropdown .ampstart-dropdown-item,.ampstart-nav-dropdown .ampstart-dropdown>section>header{background-color:#fff;color:#000}.ampstart-nav-dropdown .ampstart-dropdown-item{color:#003f93}.ampstart-sidebar{background-color:#fff;color:#000;min-width:300px;width:300px}.ampstart-sidebar .ampstart-icon{fill:#003f93}.ampstart-sidebar-header{line-height:3.5rem;min-height:3.5rem}.ampstart-sidebar .ampstart-dropdown-item,.ampstart-sidebar .ampstart-dropdown header,.ampstart-sidebar .ampstart-faq-item,.ampstart-sidebar .ampstart-nav-item,.ampstart-sidebar .ampstart-social-follow{margin:0 0 2.5rem}.ampstart-sidebar .ampstart-nav-dropdown{margin:0}.ampstart-sidebar .ampstart-navbar-trigger{line-height:inherit}.ampstart-navbar-trigger svg{pointer-events:none}.ampstart-icon{fill:#003f93}@keyframes a{0%{transform:translateY(100%);opacity:.5}to{transform:translateY(0);opacity:1}}amp-consent{background:#fff;animation:.5s ease-out 0s 1 a}.ampstart-headerbar-nav>ul{-ms-flex-pack:end;justify-content:flex-end}.ampstart-headerbar-nav .ampstart-nav-item{padding-right:1rem}.ampstart-headerbar-nav .ampstart-nav-item a{font-size:.875rem}.ampstart-footer{max-width:1024px;margin-left:auto;margin-right:auto;position:relative;-ms-flex-direction:row-reverse;flex-direction:row-reverse;padding-top:2.5rem;padding-left:calc(5rem - 1rem);padding-right:calc(5rem - 1rem)}
            .ampstart-dropdown>section>header:after { display: inline-block;content: "+";padding: 0 0 0 1rem;color: #fff; }
        </style>
        <style amp-boilerplate>
          body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}
        </style>
        <noscript><style amp-boilerplate>body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}</style></noscript>

        <script async src="https://cdn.ampproject.org/v0.js"></script>
        <script async custom-element="amp-form" src="https://cdn.ampproject.org/v0/amp-form-0.1.js"></script>
        <script async custom-element="amp-analytics" src="https://cdn.ampproject.org/v0/amp-analytics-0.1.js"></script>
        <script async custom-element="amp-sidebar" src="https://cdn.ampproject.org/v0/amp-sidebar-0.1.js"></script>
        <script async custom-element="amp-accordion" src="https://cdn.ampproject.org/v0/amp-accordion-0.1.js"></script>
        <script async custom-element="amp-bind" src="https://cdn.ampproject.org/v0/amp-bind-0.1.js"></script>
        <script async custom-element="amp-facebook-like" src="https://cdn.ampproject.org/v0/amp-facebook-like-0.1.js"></script>        
        <script async custom-element="amp-social-share" src="https://cdn.ampproject.org/v0/amp-social-share-0.1.js"></script>
        <script async custom-element="amp-font" src="https://cdn.ampproject.org/v0/amp-font-0.1.js"></script>
    </head>
    <body>

        <!-------------------- My Custom Navbar ------------------------------>
            <header class="ampstart-headerbar fixed flex justify-start items-center top-0 left-0 right-0 pl2 pr4" style="background-color:#2e4193;padding: 0.7rem 2.5rem;color:#fff;border-bottom: 2px solid #3257a2;">
                <div role="button" on="tap:cust-header-sidebar.toggle" tabindex="0" class="ampstart-navbar-trigger md-hide lg-hide pr2" style="margin: auto 0;">☰</div>
                <amp-img src="static/img/logo/65_triangle_white.png" width="65" height="65" layout="intrinsic" class="logo_media my0 mx-auto" alt="Facebook Video Downloader" title="Facebook Video Downloader">
                </amp-img>
                <nav class="ampstart-headerbar-nav ampstart-nav xs-hide sm-hide" style="margin: auto;">
                    <ul class="list-reset center m0 p0 flex justify-center nowrap">
                        <li class="ampstart-nav-item ">
                            <a href="#" class="text-decoration-none block" style="color:#fff;font-size: 17px;"><amp-img layout="intrinsic" src="static/img/chrome.png" class="ext_img" alt="Chrome Extension for downloading facebook video" width="17" height="17" style="vertical-align: middle;"></amp-img>&nbsp;<b>Chrome Extension</b></a>
                        </li>
                        <li class="ampstart-nav-item ampstart-nav-dropdown relative"> 
                            <!-- Start Dropdown -->
                            <amp-accordion layout="container" disable-session-states="" class="ampstart-dropdown absolute top-0 left-0 right-0 bottom-0">
                            <section>
                                <header style="background-color:#2e4193;color:#fff;"><b>How to?</b></header>
                                <ul class="dropdown-menu" style="padding:1px 0;min-width: 200px;">
                                    <li><a href="how-to-use.php" style="padding: 8px 15px;border-bottom: 1px solid #eee;color:#3257a2;font-size: 17px;"><b>How to use?</b></a></li>
                                    <li><a href="how-to-download-facebook-video.php" style="padding: 8px 15px;border-bottom: 1px solid #eee;color:#3257a2;font-size: 17px;"><b>How to use Extension?</b></a>
                                    </li>
                                    <!--<li role="separator" class="divider"></li>-->
                                    <li><a href="faq.php" style="padding: 8px 15px;border-bottom: 1px solid #eee;color:#3257a2;font-size: 17px;"><b>FAQ</b></a></li>
                                    <li><a href="https://www.youtube.com/watch?v=lLv_7EZWA1s" target="_blank" style="padding: 8px 15px;border-bottom: 1px solid #eee;color:#3257a2;font-size: 17px;"><b>Video Tutorial</b></a></li>
                                </ul>
                            </section>
                            </amp-accordion>                
                            <!-- End Dropdown -->
                        </li> 
                        <li class="ampstart-nav-item ampstart-nav-dropdown relative left-align">            
                            <!-- Start Dropdown -->
                            <amp-accordion layout="container" disable-session-states="" class="ampstart-dropdown absolute top-0 left-0 right-0 bottom-0">
                                <section>
                                    <header style="background-color:#2e4193;color:#fff;"><b>More</b></header>
                                    <ul class="dropdown-menu" style="padding:1px 0;min-width: 200px;">
                                        <li><a href="how-to-use.php" style="padding: 8px 15px;border-bottom: 1px solid #eee;color:#3257a2;font-size: 17px;"><b>Facebook Video Downloader</b></a></li>
                                    </ul>
                                </section>
                            </amp-accordion> 
                            <!-- End Dropdown -->
                        </li>
                    </ul>
                </nav>
            </header>            
            <!-- Start Sidebar -->
            <amp-sidebar id="cust-header-sidebar" class="ampstart-sidebar px3 md-hide lg-hide" layout="nodisplay">
                <div class="flex justify-start items-center ampstart-sidebar-header">
                    <div role="button" on="tap:cust-header-sidebar.toggle" tabindex="0" class="ampstart-navbar-trigger items-start">✕</div>
                </div>
                <nav class="ampstart-sidebar-nav ampstart-nav">
                    <ul class="list-reset m0 p0 ampstart-label">
                        <li class="ampstart-nav-item"><a href="#"style="color:#3257a2;"><amp-img layout="intrinsic" src="static/img/chrome.png" class="ext_img" alt="Chrome Extension for downloading facebook video" width="17" height="17" style="vertical-align: middle;"></amp-img>&nbsp;<b>Chrome Extension</b></a></li>
                        <li class="ampstart-nav-item ampstart-nav-dropdown relative">
                            <!-- Start Dropdown-inline -->
                            <amp-accordion layout="container" disable-session-states="" class="ampstart-dropdown">
                                <section>
                                    <header style="color:#3257a2;"><b>How to?</b></header>
                                    <ul class="ampstart-dropdown-items list-reset m0 p0">
                                        <li class="ampstart-dropdown-item"><a href="#" class="text-decoration-none left-align">How to use?</a></li>
                                        <li class="ampstart-dropdown-item"><a href="#" class="text-decoration-none left-align">How to use Extension?</a></li>
                                        <li class="ampstart-dropdown-item"><a href="#" class="text-decoration-none left-align">FAQ</a></li>
                                        <li class="ampstart-dropdown-item"><a href="#" class="text-decoration-none left-align">Video Tutorial</a></li>
                                    </ul>
                                </section>
                            </amp-accordion>
                            <!-- End Dropdown-inline -->
                        </li>            
                        <li class="ampstart-nav-item ampstart-nav-dropdown relative">             
                            <!-- Start Dropdown-inline -->
                            <amp-accordion layout="container" disable-session-states="" class="ampstart-dropdown">
                                <section>
                                    <header style="color:#3257a2;"><b>More</b></header>
                                    <ul class="ampstart-dropdown-items list-reset m0 p0">
                                        <li class="ampstart-dropdown-item"><a href="#" class="text-decoration-none">Facebook Video Downloader</a></li>
                                    </ul>
                                </section>
                            </amp-accordion>                    
                            <!-- End Dropdown-inline -->
                        </li>
                    </ul>
                </nav> 
            </amp-sidebar>
            <!-- End Sidebar -->
        <!-------------------- End Custom Navbar ----------------------->
        <div class="slider-show">
            <div class="container">
                <div class="slider-show-inner width-full">	
                    <div class="row">
                        <div class="header">			  
                          <div class="text-center"> 
                            <a href="https://play.google.com/store/apps/details?id=com.karma.videodownloader" target="_blank"><amp-img layout="intrinsic" class="img-full-btn" src="static/img/imgpsh_fullsize.png" width="133" height="40" alt="Facebook Video Downloader"></amp-img></a>
                          </div>
                          <h1>Facebook Video Downloader</h1>
                          <h2>Download Facebook Videos Online </h2>        
                        </div>
                    </div> 
                    <div class="searchForm">
                        <div style="margin: 15px 0px;">
                            <form id="downloadForm" method="get" action="facebook-video-download.php" target="_blank">
                                <input name="video" class="url-input" type="text" id="url" placeholder="Enter Facebook video link..." >
                                <button type="submit"  id="downloadBtn" value="Download"><span class="glyphicon glyphicon-download-alt"></span> &nbsp; Download</button> 
                            </form>
                        </div>           
                    </div> 
                    <div class="col"></div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="align-text-dec">
            <div class="container">
                <!-- facebook like button -->
                <div class="text-center fb_like">
                  <amp-facebook-like
                    width="88" height="28" data-size="large" data-layout="button_count" data-href="https://www.facebook.com/Video-Downloader-291928234745738/">
                  </amp-facebook-like>
                </div>
                <div class="text-center">
                  <amp-social-share class="rounded" type="gplus" width="48" height="48"></amp-social-share>
                  <amp-social-share class="rounded" type="facebook"
                    width="48" height="48" data-param-app_id="2221189334769023"></amp-social-share>
                  <amp-social-share class="rounded" type="twitter" width="48" height="48"></amp-social-share>
                </div>
                
                <!-- how to use section -->
                <div class="text-center howtouse_section">
                  <h2>How To Use Facebook Video Downloader</h2>
                  <hr>
                  <div class="col-md-4">
                      <div class="icon">
                        <amp-img layout="intrinsic" src="static/img/Facebook-Video-Downloader.png" alt="Facebook Video Downloader"  width="70" height="70"></amp-img>
                      </div>
                      <h4 class="text-left">1. How to Copy Video Link</h4>
                      <ul class="text-left">
                        <li>Then right click on it.</li>
                        <li>Choose "Show Video Url".</li>
                        <li>Copy url.</li>
                      </ul> 
                  </div>
                  <div class="col-md-4">
                      <div class="icon">
                        <amp-img layout="intrinsic" src="static/img/Facebook-Video-Download.png" alt="Facebook Video Download" width="70" height="70"></amp-img>
                      </div>
                      <h4 class="text-left">2. How to Paste Video Link</h4>
                      <ul class="text-left">
                        <li>Paste Video Link into search field.</li>
                        <li>Click Download Button.</li>
                      </ul>
                  </div>
                  <div class="col-md-4">
                      <div class="icon">
                        <amp-img layout="intrinsic" src="static/img/Facebook-Video-Downloader-Online.png" alt="Facebook Video Downloader Online" width="70" height="70"></amp-img>
                      </div>
                      <h4 class="text-left">3. How to Video & mp3 Download</h4>
                      <ul class="text-left">
                        <li>Select video Quality.</li>
                        <li>You Can also download audio (.mp3).</li>
                      </ul>
                  </div>
                </div>
                <div class="clearfix"></div>
                <h2 class="text-center">Free Facebook Video Downloader Online</h2>
                <!-- <div class="panel-group"> -->
                  <div class="panel panel-default">
                    <div class="panel-heading custom_panel_heading" >Introduction</div>
                    <div class="panel-body">
                      <p>Freefbdown is a simple online tool for <b>Facebook video downloader</b>. We are the Best Free Facebook Video Downloader online tool which is very much useful in downloading Facebook videos on both desktop and mobile devices very easily.</p>
          
                      <h3>Facebook Video Downloader Online</h3>

                      <p>Download your favorite and lovable Facebook Videos online using this Facebook Video Downloader from <b>freefbdown.com</b> just Paste the URL of the Facebook video in the box above, then click <b>Download</b> to get the direct video link.</p>
                      <p>Facebook is a household name now. It is one of the most popular free social networking websites. Every day across the world, it is used by millions of users to create their profiles, upload photos or video and communicate with other users. Facebook is also beneficial to users in order to discover what's going on in the world, news updates, and other exciting articles.</p>

                      <p>Videos on Facebook are one of the most engaging ways to share and discover fascinating things. As an add-on, you can share your personal or professional video on your news feed and watch other videos too.</p>

                      <h3>Why you need Facebook Video Downloader?</h3>          
                      <p>To fulfill your needs of <b>Facebook Video Downloader</b>, all you need is FREEFBDOWN.COM. Our tool is popular because it is free and user-friendly. We are your one-stop solution provider to download video from facebook to meet all your video downloading need from all popular video sharing websites like Facebook. And to add on, users can download video which they find interesting from either their PC or tablets.</p>

                      <p>Moreover, Our <b><i>Facebook Video Downloader</i></b> tool  has some distinct features like batch download, faster speed, and scheduled download which are going to be a lot of help for someone with bulk video downloading need. So enjoy downloading unlimited videos from Facebook with FREEFBDOWN.COM.</p>

                      <p>There are various reasons why users might want to download their own or other users Facebook video. The reasons could be:</p>
                      
                      <ul>
                        <li>To save favorite videos on laptop or tablet to watch it later</li>
                        <li>To share the videos outside of the Facebook world.</li>
                        <li>To upload it on your personal or company website or even blog site.</li>              
                        <li>To upload it to your YouTube channel.</li>
                        <li>To just store it on your computer for future use.</li>
                      </ul>
                    </div>
                  </div>
                  <div class="panel panel-default">
                    <div class="panel-heading custom_panel_heading">Using the <strong>FREEFBDOWN.COM</strong></div>
                    <div class="panel-body">
                      <p><strong>Do you wish to download Facebook videos from Facebook video downloader quickly and Free of charge?</strong></p>

                      <p>Then we can help you with it. With our website <a href="<?php echo $base_link; ?>"><b>FREEFBDOWN.COM.</b></a>, you can download videos from Facebook in a quick and easy manner.</p>
                      
                      <p>Freefbdown is a simple Free <b>Facebook video downloader</b> which directly grabs the MP4 or Flv video links for the Facebook video. It is easy to use and free web-based  tool for Facebook video download. You don't need to install any software/plugins.</p>
                    </div>
                  </div>
                  <div class="panel panel-default">
                    <!-- <div class="panel-heading custom_panel_heading">Here's a quick guide on how to use it:</div> -->
                    <div class="panel-heading custom_panel_heading">How to use it:</div>
                    <div class="panel-body">

                      <ul>
                        <li>Simply browse to the video that you wish to download on Facebook, and click to play it.</li>
                        <li>Right click on the video and click ‘Show video URL’, then copy the URL link that is displayed on the page.</li>
                        <li>Head on over to <strong>FREEFBDOWN.COM</strong>, and paste the URL link into the field at the top of the page and hit <strong>‘Download’</strong>.</li>
                      </ul>

                      <p>Isn't it a free and easy method to download videos from Facebook. You can then save it on your desktop or another device for future use. </p>
                    </div>
                  </div>
                  <div class="panel panel-default">
                    <!-- <div class="panel-heading custom_panel_heading">Here's a quick guide on how to use it:</div> -->
                    <div class="panel-heading custom_panel_heading">Is it Safe to Use?</div>
                    <div class="panel-body">            
                      <p>Users are always worried about safety issues, especially when dealing with things online. And when it comes to downloading videos through a third party then they become all the more cautious.</p> 

                      <p>We at, FREEFBDOWN.COM, understand your concerns and assure you of a safe and secure experience by downloading Facebook videos with our website. </p>

                      <p>You can trust our website, for safety and quality. Also, don't worry about viruses entering your desktop or tablet when you download the video links. As we do not save your videos on our servers, using our website is safe and anonymous. We ensure that all your downloads are kept error-free. </p>
                      <p>Freefbdown is the best free <b><i>Facebook Video Downloader</i></b> online tool for your downloads. With us, downloading your favorite Facebook video has now become hassle-free. Download the videos fast with simple and easy steps without any registrations or opening an account from <b>Facebook video downloader</b> And save the videos for a later watch or other purposes.</p>
                      <p><b>Facebook Video Downloader ✔ So Happy downloading!</b></p>
                    </div>
                  </div>
                <!-- </div> -->
            </div>
        </div>
        <footer>
            <div>
              <ul>
                <li><a href="<?php echo $base_link; ?>">Home</a></li>
                <li><a href="contact-us.php">Contact Us</a></li>
                <li><a href="about-us.php">About Us</a></li>
                <li><a href="privacy-policy.php">Privacy</a></li>
              </ul>
              <p style="font-size: 15px;">Download Instagram Videos at &gt;&gt; : <strong><a style="color: #008cba;text-decoration: none;" title="Instagram video Downloader" href="https://www.insta-video-downloader.com" target="_blank" >Instagram video Downloader</a></strong></p>
            </div>
            <div class="copyright">
              Copyright © 2018 freefbdown. All rights reserved.
            </div>
        </footer>

    </body>
</html>
