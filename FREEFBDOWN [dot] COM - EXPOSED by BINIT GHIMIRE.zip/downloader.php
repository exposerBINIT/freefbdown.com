<?php

/*
	FREEFBDOWN [dot] COM - EXPOSED by BINIT GHIMIRE
	Facebook Profile: https://www.facebook.com/InternetHeroBINIT
	Facebook Page: https://www.facebook.com/thebinitghimire
	Twitter: @WHOISbinit (https://twitter.com/WHOISBinit)
	LinkedIn: https://www.linkedin.com/in/thebinitghimire
	Official Website: https://binitghimire.com.np
*/

include('includes/header.php'); 

// $url = 'https://www.facebook.com/GujjuNoJalso/videos/1374492392682550/?t=0';
// echo substr($url,strrpos(rtrim($url,'/'),'/')+1,-1);
// echo "\n\n";
// echo array_slice(explode('/',$url),-2,1)[0];

?>
<style type="text/css">
	#qrcode_btn{
	   text-decoration: none;
	   color: #636363;
	   background-color: #4FC0E7;
	   padding: 8px 15px;
	   font-weight: bold;
	   display: inline-block;
	   font-size: 14px;
	   background: linear-gradient(to bottom, #fcfcfc 0%, #f5f5f5 100%);
	   border: 1px solid #d1d1d1;
	}
	#dpbx_save{
		padding: 10px 25px;
		font-weight: bold;
		border: 1px solid #d1d1d1;
		font-size: 14px;
	}
</style>
<!--disply result-- -->
	<div class="slider-show-had"></div>
        
        <!-- google ad -->
        <div class="text-center" style="background-color: #e4e6f6!important;border: none!important;padding-top: 30px!important;">
              <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
              <ins class="adsbygoogle"
              style="display:block"
              data-ad-client="ca-pub-3832212065022513"
              data-ad-slot="2933578194"
              data-ad-format="auto"
              data-full-width-responsive="true"></ins>
              <script> (adsbygoogle = window.adsbygoogle || []).push({}); </script>
        </div>
        <!-- END google ad -->

      <div class="body-height well custom-well" id="result" style="box-shadow:none !important;padding-top:1.5% !important;padding-bottom: 2px !important;">
          <div id="downloadUrl" >
            <p class="text-center col-md-12"><a href="index.php" class="video_down"><b>Download Another Video</b></a></p>
            <!-- <div class="text-center col-md-12" style="margin-top: 10px;">
            <p class="heading-content">If you like our Extension then please, give a valueable feedback</p>
            <p><a href="<?php echo $extLink; ?>" class="btn-import-color video_down" target="blank"><b>Rate Us</b><span class="gps_ring"></span><span class="gps_ring_new"></span></a></p>
		        </div>	 -->	 
 
            <div class="row">
              <div class="container">    
                <div class="row"> 
                  <div class="col-sm-12 margin-btm text-center" id="title"></div>       
                  <div class="col-md-4 text-right" style="display:none;">
                      <!-- google ad -->
                      <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                      <!-- fb_square -->
                      <ins class="adsbygoogle"
                             style="display:inline-block;width:300px;height:300px"
                             data-ad-client="ca-pub-3832212065022513"
                             data-ad-slot="7238653978"></ins>
                      <script>
                        (adsbygoogle = window.adsbygoogle || []).push({});
                      </script>
                      <!--END google ad -->
                  </div>
                  <div class="col-xs-12 col-md-8 text-dec text-center">
				  
                      <p class="text-center" id="img">
                        <video controls muted src='<?php echo $_REQUEST['sd_video']; ?>' class="video-max" width="100%" height="300px" type="video/mp4"> Sorry, your browser does not support embedded videos.</video>
                      </p>
                  </div>
                  <div class="col-md-4 text-left">
                      <!-- google ad -->
                      <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                      <!-- fb_square -->
                      <ins class="adsbygoogle"
                             style="display:inline-block;width:300px;height:300px"
                             data-ad-client="ca-pub-3832212065022513"
                             data-ad-slot="7238653978"></ins>
                      <script>
                        (adsbygoogle = window.adsbygoogle || []).push({});
                      </script>
                      <!--END google ad -->
                  </div>
                  <div class="clearfix"></div>
                  <div class="max-box-td">
                    <div class="col-md-6">
                      <p class="text-center" id="sd">
                        <?php if($_REQUEST['sd_video']!='null'&&$_REQUEST['sd_video']!=''){ ?>
                          <a href="download.php?src=<?php echo urlencode($_REQUEST['sd_video']) ?>" download="<?php echo date('Ymdhsi').'_sd_Freefbdown.mp4'; ?>" class="video_down"><b>Download MP4 SD</b></a>
                          <?php } ?>
                      </p>
                    </div>
                    <div class="col-md-6">
                      <p class="text-center" id="hd">
                        <?php if($_REQUEST['hd_video']!='null'&&$_REQUEST['hd_video']!=''){ ?>
                          <a href="download.php?src=<?php echo urlencode($_REQUEST['hd_video']) ?>" download="<?php echo date('Ymdhsi').'_hd_Freefbdown.mp4'; ?>" class="video_down"><b>Download MP4 HD</b></a>  
                        <?php } ?>
                      </p>  
                    </div>
                    <div class="clearfix"></div>
                    <!-- QRCode section & Dropbox Section -->
                    <!-- QRCode btn -->
                    <div class="col-md-6">
                      <p class="text-center">
                        <a href="#myModal" id="qrcode_btn" data-toggle="modal"><b><span class="glyphicon glyphicon-download-alt" style="color: #0064fa;"></span>&nbsp;&nbsp;Download in Mobile</b></a>
                      </p>
                    </div>  
                    <!-- dropbox btn -->
                    <div class="col-md-6">
                      <p class="text-center">
                        <a href="<?php echo $_REQUEST['sd_video']; ?>" class="dropbox-saver" id="dpbx_save"><span class="dropin-btn-status"></span>Save to Dropbox</a>
                      </p>
                    </div>
                    <!-- QRCode modal -->
                    <div class="modal fade" id="myModal" role="dialog">
                        <div class="modal-dialog modal-sm">
                          <div class="modal-content">
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal">&times;</button>
                              <p class="modal-title">Scan the QR code to download directly to your mobile or tablet</p>
                            </div>
                            <div class="modal-body text-center"><img id="qrcode_img" src="https://chart.googleapis.com/chart?chs=200x200&cht=qr&chl=<?php echo urlencode('https://www.freefbdown.com/download.php?url='.base64_encode($_REQUEST['sd_video'])); ?>&choe=UTF-8" title="Download video in mobile"/></div>
                          </div>
                        </div>
                    </div>
                    <!-- END QRCode section & Dropbox Section -->
                  </div>
                </div>
                <div class="clearfix"></div>

            </div>
            </div>
			
			  <!-- google ad -->
          <div class="text-center" style="background-color: #e4e6f6!important;border: none!important;padding-top: 20px !important;padding-bottom: 40px;">
                <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                <ins class="adsbygoogle"
                style="display:block"
                data-ad-client="ca-pub-3832212065022513"
                data-ad-slot="2933578194"
                data-ad-format="auto"
                data-full-width-responsive="true"></ins>
                <script> (adsbygoogle = window.adsbygoogle || []).push({}); </script>
          </div>
          <!-- END google ad -->
			
          </div>
      </div>

<style>

.opicity-btn {
    opacity: 0.01;
    position: relative;
    transform: scale(1.5);
    left: -15px;
    top: 4px;
}
img.img-scale {
    position: absolute;
    width: 90px;
    left: 0;
    z-index: 0;
}
.opicity-btn div, .opicity-btn a, .opicity-btn iframe, .opicity-btn div span {
  width:100%;
} 

.heading-content {
	font-size: 20px;
	font-weight: bold;
	color: #2e4193;
	text-transform: uppercase;
}
.video_down {
	position: relative;
}
.video_down b{
	position:relative;
	z-index:999;
}
.btn-import-color.video_down{
	background:#4fc0ea;
}
.gps_ring {
	width: 100%;
	height: 100%;
	position: absolute;
	background: rgba(75, 189, 230, 0.3);
	-webkit-animation-name: pulsate;
	-webkit-animation-duration: 2s;
	-webkit-animation-timing-function: ease-in-out;
	-webkit-animation-iteration-count: infinite;
	left: 50%;
	z-index: 0;
	top: 50%;
	transform: translate(-50%, -50%);
}
.gps_ring_new {
	width: 100%;
	height: 100%;
	position: absolute;
	background: rgba(75, 189, 230, 0.3);
	-webkit-animation-name: pulsatenew;
	-webkit-animation-duration: 2s;
	-webkit-animation-timing-function: ease-in-out;
	-webkit-animation-iteration-count: infinite;
	left: 50%;
	z-index: 0;
	top: 50%;
	transform: translate(-50%, -50%);
}

@-webkit-keyframes pulsate {
    0% { width:100%; height:100%; }
	25% { width:106%; height:100%;opacity:0.5;}
    50% { width:112%; height:65px;opacity:1;}
	75% { width:106%; height:100%;opacity:0.5;}
    100% { width:100%; height:100%;}
}

@-webkit-keyframes pulsatenew {
    0% { width:100%; height:100%; }
	25% { width:112%; height:100%;opacity:0.15;}
    50% { width:122%; height:80px;opacity:1;}
	75% { width:112%; height:100%;opacity:0.15;}
    100% { width:100%; height:100%;}
}
</style>

<!-- footer -->
<?php include('includes/footer.php'); ?>

<script type="text/javascript" async src="https://platform.twitter.com/widgets.js"></script>
<script src="https://apis.google.com/js/platform.js" async defer></script>

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v3.1&appId=2221189334769023&autoLogAppEvents=1';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<script>
      window.___gcfg = {
        lang: 'en-US',
        parsetags: 'onload'
      };
</script>

