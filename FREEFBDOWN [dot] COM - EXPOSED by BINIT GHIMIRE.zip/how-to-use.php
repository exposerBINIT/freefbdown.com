<?php include('includes/header.php'); ?>


<div class="jumbotron body-custom-well">
	<div class="container">
		<div class="row clearfix">
			<div class="col-md-12 column">
				<div class="text-center">
					<!-- <a href="https://www.freefbdown.com" class="text-center"><img class="img-responsive" src="static/img/logo/logo_blue.png" alt="Download Facebook Videos" title="Facebook Video Downloader Online" width="240px"></a> -->
				<!-- <p>Facebook Video Downloader</p> -->
					<h2 class="heading-bloger">How to Download Facebook Videos</h2>
					<div style="text-align:left;line-height: 35px;font-size: 10px !important">
						<h3>Step 1</h3>
						<p>Play the video, then <strong>Right Click -&gt; Show video URL</strong>. See screenshot 	below.</p>
						<a href="static/img/how_to_use/step-1.png" title="Click to open the image in a new tab" target="_blank"><img class="img-responsive img-thumbnail" width="620px" src="static/img/how_to_use/step-1.png"></a>
						<br>

						<h3>Step 2</h3>
						<p>Go to <strong><a href="https://www.freefbdown.com">FREEFBDOWN.COM</a></strong>. Then <strong>paste the URL</strong> and <strong>Click 'Download'</strong>, like the screenshot below</p>
						<a href="static/img/how_to_use/new-step-2.png" title="Click to open the image in a new tab" target="_blank"><img class="img-responsive img-thumbnail" width="620px" src="static/img/how_to_use/new-step-2.png"></a>
						<br>

						<h3>Step 3</h3>
						<p>Click on <strong>"Download normal quality video"</strong> or <strong>"Download HD video"</strong> (if available) to start downloading the video.</p>
						<a href="static/img/how_to_use/new-step-3.png" title="Click to open the image in a new tab" target="_blank"><img class="img-responsive img-thumbnail" width="620px" src="static/img/how_to_use/new-step-3.png"></a>
						<br>
					</div>
				 </div>
			</div>
		</div>
	</div>
</div>

<?php include('includes/footer.php'); ?>