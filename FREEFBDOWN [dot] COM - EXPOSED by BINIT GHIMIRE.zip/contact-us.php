<?php include('includes/header.php'); ?>

<div class="body-custom-well">
<div class="container">
<div class="row clearfix">
<div class="col-md-12 column">
<div class="text-center">
    <h1 style="font-size:24px;margin-top:1%;">Facebook Video Downloader</h1>
    <h2 style="margin-top: 0%;font-size:26px;"><small>Contact us</small></h2>
</div>
<div class="col-md-6 col-md-offset-3">
<form id="contact_form">
<div class="form-group">
<label for="namex">Name: *</label>
<input class="form-control input-lg" id="namex" name="name" type="text" required>
</div>
<div class="form-group">
<label for="emailx">Email: *</label>
<input class="form-control input-lg" id="emailx" name="email" type="email" required>
</div>
<div class="form-group">
<label for="subjectx">Subject: *</label>
<input class="form-control input-lg" id="subjectx" name="subject" type="text"required>
</div>
<div class="form-group">
<label for="video_linkx">Video URL: <span class="text-muted">(optional)</span></label>
<input class="form-control" id="video_linkx" name="video_url" type="text">
</div>
<div class="form-group">
<label for="messagex">Message: *</label>
<textarea class="form-control input-lg" id="messagex" name="message" required></textarea>
</div>
<input type="hidden" name="opt_type" value="add_contact">
<input class="btn-submit btn btn-primary input-lg" type="submit" id="submit" value="Send Message"><br>
<div id="message_status" class="alert alert-success" role="alert" style="margin-top:10%;display:none"></div>
</form>
</div>
</div>
</div>
</div>
</div>

<?php include('includes/footer.php'); ?>
<script type="text/javascript">
	$(document).ready(function (e) {

    $("#contact_form").on('submit',(function(e) {
        e.preventDefault();
        var formData = new FormData(this);
        $.ajax({
            url: "ajaxdata.php",
            type: "post",
            data:  new FormData(this),
            contentType: false,
            cache: false,
            processData:false,
            success: function(result)
            {                
                if( result.trim() == '1') 
                { alert('Successfully send.');}else{ alert('Oops,something went wrong!');}
                location.reload();
            },
            error:function(){ alert('Oops,something went wrong!');location.reload(); }
       });
    }));

});
</script>