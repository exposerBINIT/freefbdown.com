<?php 
$con = mysqli_connect("localhost","freefbdo_freefbd","S$2Zp$=o*~FO","freefbdo_freefbdown"); 

//session_start();

?>