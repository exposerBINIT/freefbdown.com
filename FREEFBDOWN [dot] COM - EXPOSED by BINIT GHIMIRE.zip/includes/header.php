<?php  
 
  $base_url=(isset($_SERVER['HTTPS'])&&$_SERVER['HTTPS']==='on'?"https":"http")."://$_SERVER[HTTP_HOST]";
  $actual_link=(isset($_SERVER['HTTPS'])&&$_SERVER['HTTPS']==='on'?"https":"http")."://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

  include('comman.php'); 
  if(isOpenedFrom() === true){
    header('Location: amp-index.php?#development=1');
  }
 
  $browser=BrowserWiseExtension(); 
  if($browser=='firefox'){
      $extLink = 'https://addons.mozilla.org/en-US/firefox/addon/video-downloader-for-fb/';
      $extBtnLable = 'Firefox Extension';
      $extImg = $base_url.'/static/img/Mozilla_Firefox_72-72.png';
  }else{
      $extLink = 'https://chrome.google.com/webstore/detail/freefbdown-video-download/epkpmkghpohjnpojfnjkgpnhbmjbbiik';
      $extBtnLable='Chrome Extension';
      $extImg = $base_url.'/static/img/chrome.png';    
  }
 
  if($actual_link == $base_url.'/how-to-download-facebook-video.php'){ 
    $title = "How to Download Facebook Video";
    $description="How to Download Facebook Video, Few steps for download Facebook Video from your facebook account.";
    $keywords="Facebook Video Downloader, Free Facebook Video Downloader, Online Facebook video Downloader, Facebook Video Downloader Online";  

  }else if($actual_link == $base_url.'/how-to-use.php'){ 
    $title = "How to Use - How to Download Facebook Videos from freefbdown.com";
    $description="Easy Steps, How to Use, How to Download Facebook Videos from freefbdown.com";
    $keywords="Facebook Video Downloader, Free Facebook Video Downloader, Online Facebook video Downloader, Facebook Video Downloader Online";  

  }else if($actual_link == $base_url.'/privacy-policy.php'){ 
    $title = "Privacy Policy";
    $description="Privacy Policy";
    $keywords="Facebook Video Downloader, Online Facebook video Downloader, Free Facebook Video Downloader, Facebook Video Downloader Online";

  }else if($actual_link == $base_url.'/about-us.php'){ 
    $title = "About Us - freefbdown.com";
    $description="freefbdown website helps you download facebook video online for free, with this tool you can save facebook videos without any Software.";
    $keywords="Facebook Video Downloader, Online Facebook video Downloader, Free Facebook Video Downloader, Facebook Video Downloader Online";  

  }else if($actual_link == $base_url.'/contact-us.php'){ 
    $title = "Contact Us - freefbdown.com";
    $description="freefbdown.com helps you to download facebook videos online for free, freefbdown tool you can also save facebook videos in your device without any Software.";
    $keywords="Free Facebook Video Downloader, Facebook Video Downloader, Online Facebook video Downloader, Facebook Video Downloader Online"; 

  }else if($actual_link == $base_url.'/faq.php'){ 
    $title = "Frequently Asked Questions";
    $description="Frequently Asked Questions at freefbdown.com.";
    $keywords="Facebook Video Downloader, Online Facebook video Downloader, Free Facebook Video Downloader, Facebook Video Downloader Online"; 

  }else if($actual_link == $base_url.'/facebook-video-downloader/'){ 
    $title = "Facebook Video Downloader Online from Freefbdown.com";
    $description="Best Facebook Video Downloader Online - Freefbdown.com is the free facebook video downloader online.";
    $keywords="Download Video From Facebook, Online Download Video From Facebook, Tool Download Video From Facebook, Free Download Video From Facebook, Easy Download Video From Facebook";
    
  }else if($actual_link == $base_url.'/facebook-private-video-downloader/'){ 
    $title = "Private Facebook Video Downloader | How to Download Private Facebook Video Online Free";
    $description="Private Facebook Video Downloader Online - We provide you best tips for how to download private facebook video online free. Download private facebook video using Freefbdown.com online facebook private video downloader for free.";
    $keywords="Download Private Video From Facebook, Online Download Private Video From Facebook, Tool Download Private Video From Facebook, Free Download Private Video From Facebook, Easy Download Private Video From Facebook";
    
  }else{
    $title = "Facebook Video Downloader | Download Facebook Videos Online Full HD";
    $description="Facebook Video Downloader - Download Facebook videos full hd and save them to your computer or Smart Phone. Best facebook videos downloader online to save videos from facebook with high quality.";
    $keywords="Free Facebook Video Downloader, Online Facebook Video Downloader, Facebook Video Downloader Online, Download Facebook Videos Free, Facebook Video Downloader, Online tool for Facebook Video Downloader, Best Online tool facebook Video Downloader, Online tool for Facebook Video Downloader";  
  } 

?>

<!DOCTYPE html> 
<html lang="en" prefix="fb: http://www.facebook.com/2008/fbml" itemscope itemtype="http://schema.org/WebPage">
<head>
  <meta charset="utf-8">  
  <meta name="geo.region" content="IN-GJ" />
  <meta name="geo.placename" content="Ahmedabad" />
  <meta name="geo.position" content="23.021624;72.579707" />
  <meta name="ICBM" content="23.021624, 72.579707" />
  <meta name="classification" content="Facebook Video Downloader" />
  <meta name="language" content="English" />
  <meta name="GOOGLEBOT" content="index, follow" />
  <meta name="Robots" content="index, follow" />
  <meta name="Search Engine" content="https://www.Google.com" />
  <meta name="OWNER" content="Facebook Video Downloader" />
  <meta name="author" content="Facebook Video Downloader" />
  <meta name="copyright" content="Facebook Video Downloader" /> 
  <meta name="expires" content="Never" />
  <meta name="RATING" content="General" />
  <meta name="REVISIT-AFTER" content="1 day" />

  <title><?= $title; ?></title>
  <meta name="description" content="<?= $description; ?>">
  <meta name="keywords" content="<?= $keywords; ?>">
  <meta name="google-site-verification" content="HhfHjyP-TLAolLoiXfGiX_WxQu03akpfhdCvKPBgA4E" />
  <meta name="author" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=3">
  <!-- meta tag for facebook -->
  <meta property="fb:app_id" content="2221189334769023">
    <link rel="image_src" type="image/png" href="<?php echo $base_link.'/static/img/logo/video_downloader.png'; ?>">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="freefbdown.com"/>
  <meta property="og:url" content="<?php echo $base_link; ?>"/>
  <meta property="og:title" content="Freefbdown - video downloader" /> 
  <meta property="og:description" content="Download Facebook Videos, Download Video HD MP4 and Save them directly from facebook to your mobile or computer in HD and MP4." />   
  <meta property="og:image" content="<?php echo $base_link.'/static/img/logo/video_downloader.png'; ?>" />
  <meta property="og:image:width" content="400" />
  <meta property="og:image:height" content="300" />
  <!-- meta tag for twitter -->
  <meta property="twitter:image" content="<?php echo $base_link.'/static/img/logo/video_downloader.png'; ?>" />
  <meta itemprop="name" content="Download Facebook Videos, Download Video HD MP4 and Save them directly from facebook to your mobile or computer in HD and MP4.">
  <meta itemprop="description" content="Download Facebook Videos, Download Video HD MP4 and Save them directly from facebook to your mobile or computer in HD and MP4.">

  <link rel="canonical" href="<?php echo $actual_link; ?>" />
  <link rel="alternate" href="<?php echo $actual_link; ?>" hreflang="x-default" />
  <link rel="shortcut icon" href="<?php echo $base_url; ?>/static/img/logo/video_down_favicon.ico" type="image/x-icon">
  <link rel="stylesheet" href="<?php echo $base_url; ?>/static/css/bootstrap.min.css?v=<?php echo rand(); ?>">
  <link rel="stylesheet" href="<?php echo $base_url; ?>/static/css/custom.css?v=<?php echo rand(); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo $base_url; ?>/static/css/header-style.css?v=<?php echo rand(); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo $base_url; ?>/static/css/attached-css.css?v=<?php echo rand(); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo $base_url; ?>/static/css/jquery.floating-social-share.min.css?v=<?php echo rand(); ?>">
 
  <!-- Global site tag (gtag.js) - Google Analytics -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=UA-124216736-1"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'UA-124216736-1');
  </script>
<script type="application/ld+json">
     {
       "@context": "https://schema.org",
       "@type": "FAQPage",
       "mainEntity": [{
         "@type": "Question",
         "name": "Where do my facebook videos go to after the download?",
         "acceptedAnswer": {
           "@type": "Answer",
           "text": "This Facebook Video Downloader usually save the video into whatever folder you have set for saving video as default. If you want to change the folder then open the browser setting and change the default download video setting manually because normally browser sets this folder for you."
         }
      }, {
         "@type": "Question",
         "name": "Does your Facebook Video Downloader work on mobile?",
         "acceptedAnswer": {
           "@type": "Answer",
           "text": "If you have an Android phone and want to download video from Facebook then using chrome browser you can easily download, so yes it works on mobile as well. You just have to paste the link of the Facebook video and you can easily download."
         }
      }, {
         "@type": "Question",
         "name": "Can I download Live Facebook videos with this downloader tool?",
         "acceptedAnswer": {
           "@type": "Answer",
           "text": "Yes, you can Online video download from Facebook. Once the streaming of Live video is done, you can save live videos to your device using this chrome extension."
         }
       }, {
         "@type": "Question",
         "name": "Does FREEFBDOWN store downloaded videos or keep a copy of videos?",
         "acceptedAnswer": {
           "@type": "Answer",
           "text":"No, FREEFBDOWN doesn�t store any downloaded videos. We respect your privacy. So, we don't store any copy of any downloaded video. All videos are hosted by Facebook servers only, so we don't keep the track of any histories of video download from Facebook."}
         }]
       }
    </script>
</head>
<body>
<nav class="header-main-bg navbar navbar-default navbar-static-top" role="navigation">
  <div class="container">
    <div class="left-logo">
	<!--<div class="navbar-header">-->
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#menu">
          <span class="sr-only">Toggle navigation</span><span class="icon-bar"></span>
          <span class="icon-bar"></span><span class="icon-bar"></span>
      </button>  
    
      <a class="logo-ahref display-logo" href="<?php echo $base_url; ?>">
        <picture>
          <source media="(max-width: 667px)" srcset="<?php echo $base_url; ?>/static/img/logo/52_triangle_white.png">
          <img src="<?php echo $base_url; ?>/static/img/logo/65_triangle_white.png" alt="Video Downloader" title="Video Downloader" style="width:auto;">
        </picture>
      </a>
      <a class="logo-ahref hide-logo" href="<?php echo $base_url; ?>">
        <picture>
          <source media="(max-width: 667px)" srcset="<?php echo $base_url; ?>/static/img/logo/52_triangle_blue.png">
          <img src="<?php echo $base_url; ?>/static/img/logo/65_triangle_blue.png" alt="Video Downloader" title="Video Downloader" style="width:auto;">
        </picture>
      </a>
    </div>
 
    <div class="collapse navbar-collapse" id="menu">
      <ul class="nav navbar-nav">
        <?php if($actual_link != $base_url.'/facebook-video-downloader/'){ ?>
        <li>
          <a href="<?php echo  $base_url; ?>/facebook-private-video-downloader/">Private video downloader</a>
        </li>
      <?php } ?>
        <li>
          <a href="<?php echo  $extLink; ?>" target="_blank"><img src="<?php echo $extImg; ?>" class="ext_img" alt="<?php echo $extBtnLable; ?> for downloading facebook video">&nbsp;<?php echo $extBtnLable; ?></a>

        </li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-question-sign"></span> How to? <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo  $base_url; ?>/how-to-use.php">How to use?</a></li>
            <li><a href="<?php echo  $base_url; ?>/how-to-download-facebook-video.php">How to use Extension? </a>
            <!--<li role="separator" class="divider"></li>-->
            <li><a href="faq.php">FAQ</a></li>
            <li><a href="https://www.youtube.com/watch?v=lLv_7EZWA1s" target="_blank">Video Tutorial</a></li>
          </ul>
        </li>
        <?php if($actual_link != $base_url.'/facebook-video-downloader/'){ ?>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">More<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo  $base_url; ?>/facebook-video-downloader/">Facebook Video Downloader</a></li>
          </ul>
        </li>
      <? } ?>
      </ul>

    </div>
  </div>
</nav>
