﻿
<footer>
  <div>
    <ul>
      <li><a href="<?php echo $base_url; ?>">Home</a></li>
      <li><a href="<?php echo $base_url; ?>/contact-us.php">Contact Us</a></li>
      <li><a href="<?php echo $base_url; ?>/about-us.php">About Us</a></li>
      <li><a href="<?php echo $base_url; ?>/privacy-policy.php">Privacy</a></li>
      <li><a href="<?php echo $base_url; ?>/terms-and-condition.php">Terms & Condition</a></li>
    </ul>
     <p style="font-size: 15px;"><strong><a style="color: #008cba;text-decoration: none;" title="Facebook video Downloader Online" href="https://www.freefbdown.com/" target="_blank" >Facebook video Downloader Online</a></strong></p>
    <p style="font-size: 15px;">Download Instagram Videos at &gt;&gt; : <strong><a style="color: #008cba;text-decoration: none;" title="Instagram video Downloader" href="https://www.insta-video-downloader.com" target="_blank" >Instagram video Downloader</a></strong></p>
  </div>
  <div class="copyright">
    Copyright © 2019 FREEFBDOWN.COM. All rights reserved.
  </div>
</footer>
  
  <script  src="<?php echo $base_url; ?>/static/js/jquery.min.js?v=<?php echo rand(); ?>" ></script>
  <script  src="<?php echo $base_url; ?>/static/js/bootstrap.min.js?v=<?php echo rand(); ?>" ></script>
  <script  src="<?php echo $base_url; ?>/static/js/sticky.js?v=<?php echo rand(); ?>" ></script>
  <script  src="<?php echo $base_url; ?>/static/js/jquery.comments.js?v=<?php echo rand(); ?>" ></script>
  <script type="text/javascript" src="https://www.dropbox.com/static/api/2/dropins.js" id="dropboxjs" data-app-key="747rorl3pe8x02p"></script>


  <script>
      $(window).load(function(){
        $(".header-main-bg").sticky({ topSpacing: 0 });
      });
  </script>

</body>
</html>
