<h4>Loading...</h4>

<form action="downloader.php" id="frm1" method="post">
	<input type="hidden" name="sd_video" value="<?php echo $_REQUEST['sd_video']; ?>">
	<input type="hidden" name="hd_video" value="<?php echo $_REQUEST['hd_video']; ?>">
</form>

<script type="text/javascript" src="static/js/jquery.min.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
     	$("#frm1").submit();
	});
</script>