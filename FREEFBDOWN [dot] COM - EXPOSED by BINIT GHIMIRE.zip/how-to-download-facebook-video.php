<?php include('includes/header.php'); ?>

<style type="text/css">
.p_fontsize{
	font-size: 20px !important;
}	
</style>

<div class="jumbotron body-custom-well">
	<div class="container">
		<div class="row clearfix">
			<div class="col-md-12 column">
				<div class="text-center">
				<!-- <a href="https://freefbdown.com"><img class="img-responsive" src="static/img/logo/logo_blue.png" alt="Download Facebook Videos" title="Facebook Video Downloader Online" width="240px"></a>
				 --><!-- <p>Facebook Video Downloader</p> -->
					<h2 class="heading-bloger" style="font-size: 25px;">How to Download Facebook Video</h2>
					<h2 class="heading-bloger" >Few steps for download Facebook Video from your facebook account.</h2>
					<div style="text-align:left;line-height: 35px;font-size: 10px !important">
						<h3>Step 1</h3>
						<p class="p_fontsize">Goto your facebook account and pause on any Video or Play it  and you will find 2 buttons below every Video and also find 2 buttons upper right corner on every video to Download in HD or SD Quality as MP4. See screenshot below:
						</p>
						<a href="static/img/download_from_facebook/step1.png" title="Click to open the image in a new tab" target="_blank"><img class="img-responsive img-thumbnail" width="620px" src="static/img/download_from_facebook/step1.png"></a>
						<br>
						<h3>Step 2</h3>
						<p class="p_fontsize">Go to any single video and you will find 2 blue buttons upper right on every video and you can also download the videos on HD or SD Quality as MP4. See screenshot below:</p>
						<a href="static/img/download_from_facebook/step2.png" title="Click to open the image in a new tab" target="_blank"><img class="img-responsive img-thumbnail" width="620px" src="static/img/download_from_facebook/step2.png"></a>
						<br>
						<h3>Step 3</h3>
						<p class="p_fontsize">Now, Click on <strong>"Download SD video"</strong> or <strong>"Download HD video"</strong> (if available) to start downloading the video.</p>
						<a href="static/img/download_from_facebook/step3.png" title="Click to open the image in a new tab" target="_blank"><img class="img-responsive img-thumbnail" width="620px" src="static/img/download_from_facebook/step3.png"></a>
						<br><br><br>
<p>Freefbdown is the best Free Online tool for <a href="https://www.freefbdown.com/"><b>Facebook Video Downloader</b></a>.</p>					</div>
				 </div>
			</div>
		</div>
	</div>
</div>

<?php include('includes/footer.php'); ?>